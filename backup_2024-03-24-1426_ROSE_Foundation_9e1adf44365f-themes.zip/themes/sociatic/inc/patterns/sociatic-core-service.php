<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Sociatic Core Service', 'sociatic' ),
	'categories' => array( 'sociatic-core' ),
	'content'    => '<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:cover {"url":"' . esc_url( SOCIATIC_URI ) . 'assets/img/bg-service-core.webp","id":3820,"dimRatio":0,"isDark":false} -->
<div class="wp-block-cover is-light"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-3820" alt="" src="' . esc_url( SOCIATIC_URI ) . 'assets/img/bg-service-core.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"padding":{"top":"100px","bottom":"100px"}}},"layout":{"type":"constrained","contentSize":"1190px"}} -->
<div class="wp-block-group" style="padding-top:100px;padding-bottom:100px"><!-- wp:group {"layout":{"type":"constrained","contentSize":"710px"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","style":{"typography":{"fontStyle":"normal","fontWeight":"800","lineHeight":"1.1"},"spacing":{"margin":{"bottom":"20px"}}},"textColor":"theme-1","className":"sociatic-animate sociatic-move-up sociatic-delay-1","fontSize":"heading-2","fontFamily":"mulish"} -->
<h2 class="wp-block-heading has-text-align-center sociatic-animate sociatic-move-up sociatic-delay-1 has-theme-1-color has-text-color has-mulish-font-family has-heading-2-font-size" style="margin-bottom:20px;font-style:normal;font-weight:800;line-height:1.1">High-impact Marketing Services To Grow Your Business</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"sociatic-animate sociatic-move-up sociatic-delay-3","layout":{"type":"constrained","contentSize":"550px"}} -->
<div class="wp-block-group sociatic-animate sociatic-move-up sociatic-delay-3"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-text-align-center has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur adipiscing elit semper dalar elementum tempus hac tellus libero accumsan dolor sit amet consctur.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:columns {"style":{"spacing":{"margin":{"top":"60px"},"blockGap":{"top":"30px","left":"30px"}}}} -->
<div class="wp-block-columns" style="margin-top:60px"><!-- wp:column {"className":"sociatic-animate sociatic-move-up sociatic-delay-5"} -->
<div class="wp-block-column sociatic-animate sociatic-move-up sociatic-delay-5"><!-- wp:group {"style":{"spacing":{"padding":{"top":"60px","right":"40px","bottom":"60px","left":"40px"}},"border":{"radius":"20px"}},"backgroundColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-white-background-color has-background" style="border-radius:20px;padding-top:60px;padding-right:40px;padding-bottom:60px;padding-left:40px"><!-- wp:group {"layout":{"type":"flex","orientation":"vertical","verticalAlignment":"center"}} -->
<div class="wp-block-group"><!-- wp:image {"id":3821,"width":60,"height":60,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/envelope-icon.webp" alt="" class="wp-image-3821" style="width:60px;height:60px" width="60" height="60"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":5,"style":{"typography":{"lineHeight":"1.2","fontStyle":"normal","fontWeight":"800"},"spacing":{"margin":{"top":"20px","bottom":"20px"}}},"textColor":"theme-1","fontSize":"heading-5","fontFamily":"mulish"} -->
<h5 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family has-heading-5-font-size" style="margin-top:20px;margin-bottom:20px;font-style:normal;font-weight:800;line-height:1.2">Email Marketing</h5>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consecte adipiscing elit sed do eiusmod tempor incidiunt ut labor.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"sociatic-animate sociatic-move-up sociatic-delay-3"} -->
<div class="wp-block-column sociatic-animate sociatic-move-up sociatic-delay-3"><!-- wp:group {"style":{"spacing":{"padding":{"top":"60px","right":"40px","bottom":"60px","left":"40px"}},"border":{"radius":"20px"}},"backgroundColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-white-background-color has-background" style="border-radius:20px;padding-top:60px;padding-right:40px;padding-bottom:60px;padding-left:40px"><!-- wp:group {"layout":{"type":"flex","orientation":"vertical","verticalAlignment":"center"}} -->
<div class="wp-block-group"><!-- wp:image {"id":3822,"width":60,"height":60,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/chart-icon.webp" alt="" class="wp-image-3822" style="width:60px;height:60px" width="60" height="60"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":5,"style":{"typography":{"lineHeight":"1.2","fontStyle":"normal","fontWeight":"800"},"spacing":{"margin":{"top":"20px","bottom":"20px"}}},"textColor":"theme-1","fontSize":"heading-5","fontFamily":"mulish"} -->
<h5 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family has-heading-5-font-size" style="margin-top:20px;margin-bottom:20px;font-style:normal;font-weight:800;line-height:1.2">Brand Strategy</h5>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consecte adipiscing elit sed do eiusmod tempor incidiunt ut labor.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"sociatic-animate sociatic-move-up sociatic-delay-7"} -->
<div class="wp-block-column sociatic-animate sociatic-move-up sociatic-delay-7"><!-- wp:group {"style":{"spacing":{"padding":{"top":"60px","right":"40px","bottom":"60px","left":"40px"}},"border":{"radius":"20px"}},"backgroundColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-white-background-color has-background" style="border-radius:20px;padding-top:60px;padding-right:40px;padding-bottom:60px;padding-left:40px"><!-- wp:group {"layout":{"type":"flex","orientation":"vertical","verticalAlignment":"center"}} -->
<div class="wp-block-group"><!-- wp:image {"id":3823,"width":60,"height":60,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/file-icon.webp" alt="" class="wp-image-3823" style="width:60px;height:60px" width="60" height="60"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":5,"style":{"typography":{"lineHeight":"1.2","fontStyle":"normal","fontWeight":"800"},"spacing":{"margin":{"top":"20px","bottom":"20px"}}},"textColor":"theme-1","fontSize":"heading-5","fontFamily":"mulish"} -->
<h5 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family has-heading-5-font-size" style="margin-top:20px;margin-bottom:20px;font-style:normal;font-weight:800;line-height:1.2">Content Writer</h5>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consecte adipiscing elit sed do eiusmod tempor incidiunt ut labor.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"style":{"spacing":{"margin":{"top":"30px"},"blockGap":{"top":"30px","left":"30px"}}}} -->
<div class="wp-block-columns" style="margin-top:30px"><!-- wp:column {"className":"sociatic-animate sociatic-move-up sociatic-delay-3"} -->
<div class="wp-block-column sociatic-animate sociatic-move-up sociatic-delay-3"><!-- wp:group {"style":{"spacing":{"padding":{"top":"60px","right":"40px","bottom":"60px","left":"40px"}},"border":{"radius":"20px"}},"backgroundColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-white-background-color has-background" style="border-radius:20px;padding-top:60px;padding-right:40px;padding-bottom:60px;padding-left:40px"><!-- wp:group {"layout":{"type":"flex","orientation":"vertical","verticalAlignment":"center"}} -->
<div class="wp-block-group"><!-- wp:image {"id":3824,"width":60,"height":60,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/search-icon.webp" alt="" class="wp-image-3824" style="width:60px;height:60px" width="60" height="60"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":5,"style":{"typography":{"lineHeight":"1.2","fontStyle":"normal","fontWeight":"800"},"spacing":{"margin":{"top":"20px","bottom":"20px"}}},"textColor":"theme-1","fontSize":"heading-5","fontFamily":"mulish"} -->
<h5 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family has-heading-5-font-size" style="margin-top:20px;margin-bottom:20px;font-style:normal;font-weight:800;line-height:1.2">SEO Management</h5>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consecte adipiscing elit sed do eiusmod tempor incidiunt ut labor.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"sociatic-animate sociatic-move-up sociatic-delay-1"} -->
<div class="wp-block-column sociatic-animate sociatic-move-up sociatic-delay-1"><!-- wp:group {"style":{"spacing":{"padding":{"top":"60px","right":"40px","bottom":"60px","left":"40px"}},"border":{"radius":"20px"}},"backgroundColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-white-background-color has-background" style="border-radius:20px;padding-top:60px;padding-right:40px;padding-bottom:60px;padding-left:40px"><!-- wp:group {"layout":{"type":"flex","orientation":"vertical","verticalAlignment":"center"}} -->
<div class="wp-block-group"><!-- wp:image {"id":3825,"width":60,"height":60,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/megaphone-icon.webp" alt="" class="wp-image-3825" style="width:60px;height:60px" width="60" height="60"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":5,"style":{"typography":{"lineHeight":"1.2","fontStyle":"normal","fontWeight":"800"},"spacing":{"margin":{"top":"20px","bottom":"20px"}}},"textColor":"theme-1","fontSize":"heading-5","fontFamily":"mulish"} -->
<h5 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family has-heading-5-font-size" style="margin-top:20px;margin-bottom:20px;font-style:normal;font-weight:800;line-height:1.2">Advertising Marketing</h5>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consecte adipiscing elit sed do eiusmod tempor incidiunt ut labor.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"sociatic-animate sociatic-move-up sociatic-delay-5"} -->
<div class="wp-block-column sociatic-animate sociatic-move-up sociatic-delay-5"><!-- wp:group {"style":{"spacing":{"padding":{"top":"60px","right":"40px","bottom":"60px","left":"40px"}},"border":{"radius":"20px"}},"backgroundColor":"white","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-white-background-color has-background" style="border-radius:20px;padding-top:60px;padding-right:40px;padding-bottom:60px;padding-left:40px"><!-- wp:group {"layout":{"type":"flex","orientation":"vertical","verticalAlignment":"center"}} -->
<div class="wp-block-group"><!-- wp:image {"id":3826,"width":60,"height":60,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/web-icon.webp" alt="" class="wp-image-3826" style="width:60px;height:60px" width="60" height="60"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":5,"style":{"typography":{"lineHeight":"1.2","fontStyle":"normal","fontWeight":"800"},"spacing":{"margin":{"top":"20px","bottom":"20px"}}},"textColor":"theme-1","fontSize":"heading-5","fontFamily":"mulish"} -->
<h5 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family has-heading-5-font-size" style="margin-top:20px;margin-bottom:20px;font-style:normal;font-weight:800;line-height:1.2">Website Traffic</h5>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consecte adipiscing elit sed do eiusmod tempor incidiunt ut labor.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group -->',
);
