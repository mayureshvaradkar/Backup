<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Sociatic Gutenverse Contact Hero', 'sociatic' ),
	'categories' => array( 'sociatic-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1190"},"gap":"no","elementId":"guten-6gzmBc","background":{"type":"default","color":{"r":255,"g":246,"b":239,"a":1}},"backgroundOverlay":{"type":"default","image":{"Desktop":{"id":3895,"image":"' . esc_url( SOCIATIC_URI ) . 'assets/img/hero-page-bg.webp"},"Mobile":{"id":3944,"image":"' . esc_url( SOCIATIC_URI ) . 'assets/img/bg-hero.webp"},"Tablet":{"id":3944,"image":"' . esc_url( SOCIATIC_URI ) . 'assets/img/bg-hero.webp"}},"position":{"Desktop":"center center","Tablet":"custom","Mobile":"custom"},"repeat":{"Desktop":"no-repeat"},"size":{"Desktop":"default"},"xposition":{"Tablet":{"unit":"%","point":""},"Mobile":{"unit":"%","point":""}},"yposition":{"Tablet":{"unit":"%","point":"60"},"Mobile":{"unit":"%","point":"58"}}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"-100"}},"Tablet":[],"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"200","bottom":"120"}},"Tablet":{"unit":"px","dimension":{"right":"20","left":"20","top":"160"}},"Mobile":{"unit":"px","dimension":{"right":"20","left":"20","top":"140","bottom":"80"}}}} -->
<div class="section-wrapper" data-id="6gzmBc"><section class="wp-block-gutenverse-section guten-element guten-section guten-6gzmBc layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-KyPELM","border":{"radius":{"Desktop":[]}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-KyPELM"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="KyPELM"><div class="guten-column-wrapper"><!-- wp:gutenverse/section {"width":{"Desktop":"1190"},"isChild":true,"gap":"no","elementId":"guten-FjnLeS"} -->
<div class="section-wrapper" data-id="FjnLeS"><section class="wp-block-gutenverse-section guten-element guten-section guten-FjnLeS layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":50,"Tablet":60},"elementId":"guten-YPBrSm"} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-YPBrSm"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="YPBrSm"><div class="guten-column-wrapper"><!-- wp:gutenverse/heading {"elementId":"guten-NAcgD9","type":1,"color":{"type":"variable","id":"theme-1"},"typography":{"type":"variable","id":"1Isv3n","font":{"label":"Muli","value":"Muli","type":"google"},"size":{"Desktop":{"point":"56","unit":"px"},"Mobile":{"point":"36","unit":"px"},"Tablet":{"point":"44","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.1"}},"weight":"800"},"margin":{"Desktop":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}}},"padding":{"Desktop":[]},"animation":{"type":{"Desktop":"fadeInUp"},"duration":"normal","delay":"100"},"advanceAnimation":{"actions":[],"loadOn":"hover"}} -->
<h1 class="wp-block-gutenverse-heading guten-element guten-NAcgD9 animated guten-element-hide desktop-fadeInUp">Contact</h1>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/text-editor {"elementId":"guten-CGYI2v","textColor":{"type":"variable","id":"theme-2"},"typography":{"type":"variable","id":"a0sRlN","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"weight":"400"},"margin":{"Tablet":[],"Mobile":[]},"padding":{"Tablet":[],"Mobile":[]},"positioningType":{"Desktop":"custom","Tablet":"custom","Mobile":"full"},"positioningWidth":{"Desktop":{"unit":"%","point":"64"},"Tablet":{"point":"1000","unit":"px"},"Mobile":{"unit":"%","point":"90"}}} -->
<div class="guten-element gutenverse-text-editor guten-CGYI2v"><div class="text-content-inner"><!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet consectetur adipiscing elit Ut elit tellus luctus nec ullamcorper mattis.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:gutenverse/text-editor --></div></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":50,"Tablet":40,"Mobile":null},"elementId":"guten-SHYC7e","verticalAlign":{"Desktop":"center","Tablet":"center"},"margin":{"Mobile":[]},"padding":{"Mobile":{"unit":"px","dimension":{"top":"20"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-SHYC7e"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="SHYC7e"><div class="guten-column-wrapper"><!-- wp:gutenverse/icon-list {"elementId":"guten-Kfoc0N","displayInline":true,"spaceBetween":{"Desktop":"10"},"alignList":{"Desktop":"flex-end","Mobile":"flex-start"},"iconColor":{"type":"variable","id":"theme-0"},"textColor":{"type":"variable","id":"theme-2"},"textIndent":{"Desktop":"12"},"textTypography":{"type":"variable","id":"YAPBT8","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"18","unit":"px"},"Tablet":{"point":"18","unit":"px"},"Mobile":{"point":"16","unit":"px"}},"weight":"500","lineHeight":{"Desktop":{"unit":"em","point":"1"}}}} -->
<div class="guten-element guten-icon-list guten-Kfoc0N inline-icon-list"><!-- wp:gutenverse/icon-list-item {"elementId":"guten-hyTyXM","hideIcon":true} -->
<div class="guten-element guten-icon-list-item guten-hyTyXM"><a id="guten-hyTyXM"><span class="list-text no-icon">Home</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-L9u32O"} -->
<div class="guten-element guten-icon-list-item guten-L9u32O"><a id="guten-L9u32O"><i class="fas fa-chevron-right"></i><span class="list-text ">Contact</span></a></div>
<!-- /wp:gutenverse/icon-list-item --></div>
<!-- /wp:gutenverse/icon-list --></div></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
);
