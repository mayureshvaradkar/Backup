<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Sociatic Core About', 'sociatic' ),
	'categories' => array( 'sociatic-core' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"50px","bottom":"100px","right":"20px","left":"20px"}}},"layout":{"type":"constrained","contentSize":"1190px"}} -->
<div class="wp-block-group" style="padding-top:50px;padding-right:20px;padding-bottom:100px;padding-left:20px"><!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"40px","left":"40px"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"sociatic-animate sociatic-move-up sociatic-delay-1"} -->
<figure class="wp-block-image size-large sociatic-animate sociatic-move-up sociatic-delay-1" id="about"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/Image-core-about.webp" alt=""/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"padding":{"top":"50px"}}}} -->
<div class="wp-block-column is-vertically-aligned-center" style="padding-top:50px"><!-- wp:heading {"style":{"typography":{"fontStyle":"normal","fontWeight":"800","lineHeight":"1.1"},"spacing":{"margin":{"bottom":"20px"}}},"textColor":"theme-1","className":"sociatic-animate sociatic-move-left sociatic-delay-1","fontSize":"heading-2","fontFamily":"mulish"} -->
<h2 class="wp-block-heading sociatic-animate sociatic-move-left sociatic-delay-1 has-theme-1-color has-text-color has-mulish-font-family has-heading-2-font-size" id="sociatic-about" style="margin-bottom:20px;font-style:normal;font-weight:800;line-height:1.1">The Right Decision For Your Marketing Strategy</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","className":"sociatic-animate sociatic-move-left sociatic-delay-3","fontFamily":"hind-siliguri"} -->
<p class="sociatic-animate sociatic-move-left sociatic-delay-3 has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua Ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur excepteur sint occaecat cupidatat non proident.</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"margin":{"top":"40px"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center" style="margin-top:40px"><!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"padding":{"bottom":"20px"}}},"className":"sociatic-animate sociatic-move-left sociatic-delay-5"} -->
<div class="wp-block-column is-vertically-aligned-center sociatic-animate sociatic-move-left sociatic-delay-5" style="padding-bottom:20px"><!-- wp:group {"style":{"spacing":{"blockGap":"20px"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":3819,"width":60,"height":60,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/ceo.webp" alt="" class="wp-image-3819" style="width:60px;height:60px" width="60" height="60"/></figure>
<!-- /wp:image -->

<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":6,"style":{"typography":{"fontStyle":"normal","fontWeight":"800","lineHeight":"1.2"}},"textColor":"theme-1","fontSize":"heading-6","fontFamily":"mulish"} -->
<h6 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family has-heading-6-font-size" style="font-style:normal;font-weight:800;line-height:1.2">Hugo Baron</h6>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.7"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.7">CEO and Co-Founder</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"padding":{"bottom":"20px"}}},"className":"sociatic-animate sociatic-move-left sociatic-delay-7"} -->
<div class="wp-block-column is-vertically-aligned-center sociatic-animate sociatic-move-left sociatic-delay-7" style="padding-bottom:20px"><!-- wp:buttons {"className":"is-style-custombuttonstyle3"} -->
<div class="wp-block-buttons is-style-custombuttonstyle3"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">More About Us</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->',
);
