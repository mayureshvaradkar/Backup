<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Sociatic Core Single', 'sociatic' ),
	'categories' => array( 'sociatic-core' ),
	'content'    => '<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:cover {"url":"' . esc_url( SOCIATIC_URI ) . 'assets/img/hero-page-bg-core.webp","id":3800,"dimRatio":0,"minHeight":500,"isDark":false} -->
<div class="wp-block-cover is-light" style="min-height:500px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-3800" alt="" src="' . esc_url( SOCIATIC_URI ) . 'assets/img/hero-page-bg-core.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"margin":{"top":"80px"}}},"layout":{"type":"constrained","contentSize":"1190px"}} -->
<div class="wp-block-group" style="margin-top:80px"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center","width":"80%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:80%"><!-- wp:post-title {"level":1,"style":{"typography":{"fontStyle":"normal","fontWeight":"800","lineHeight":"1.1"},"spacing":{"margin":{"bottom":"40px"}}},"textColor":"theme-1","className":" sociatic-animate sociatic-move-up sociatic-delay-1","fontSize":"heading-page","fontFamily":"mulish"} /-->

<!-- wp:group {"layout":{"type":"constrained","contentSize":"1140px","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center","width":"150px"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:150px"><!-- wp:group {"style":{"spacing":{"blockGap":"10px"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":3878,"width":17,"height":20,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/admin.webp" alt="" class="wp-image-3878" width="17" height="20"/></figure>
<!-- /wp:image -->

<!-- wp:post-author {"showAvatar":false,"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"},"spacing":{"margin":{"top":"10px"}}},"textColor":"theme-2","fontFamily":"hind-siliguri"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"style":{"spacing":{"blockGap":"10px"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":3879,"width":18,"height":18,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/clock.webp" alt="" class="wp-image-3879" width="18" height="18"/></figure>
<!-- /wp:image -->

<!-- wp:post-date {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"},"spacing":{"margin":{"top":"10px"}}},"textColor":"theme-2","fontFamily":"hind-siliguri"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"20%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:20%"></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group -->',
);
