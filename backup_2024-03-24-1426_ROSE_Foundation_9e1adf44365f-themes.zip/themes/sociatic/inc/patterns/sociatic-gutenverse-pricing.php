<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Sociatic Gutenverse Pricing', 'sociatic' ),
	'categories' => array( 'sociatic-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1190"},"gap":"no","elementId":"guten-BgaclZ","margin":{"Desktop":[],"Tablet":[],"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"10","bottom":"120","right":"","left":""}},"Tablet":{"unit":"px","dimension":{"right":"20","left":"20","bottom":"100","top":"0"}},"Mobile":{"unit":"px","dimension":{"right":"20","left":"20","top":"0","bottom":"80"}}}} -->
<div class="section-wrapper" data-id="BgaclZ"><section class="wp-block-gutenverse-section guten-element guten-section guten-BgaclZ layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100,"Tablet":null,"Mobile":null},"elementId":"guten-aOx6y2","horizontalAlign":{"Desktop":"default","Tablet":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-aOx6y2"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="aOx6y2"><div class="guten-column-wrapper"><!-- wp:gutenverse/heading {"elementId":"guten-khF1fp","textAlign":{"Desktop":"center"},"color":{"type":"variable","id":"theme-1"},"typography":{"type":"variable","id":"oTRAFP","font":{"label":"Muli","value":"Muli","type":"google"},"size":{"Desktop":{"point":"46","unit":"px"},"Mobile":{"point":"32","unit":"px"},"Tablet":{"point":"44","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.1"}},"weight":"800"},"margin":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"20","left":"0"}},"Tablet":{"unit":"px","dimension":{"top":"0"}},"Mobile":[]},"padding":{"Desktop":{"unit":"%","dimension":{"right":"","left":"","top":"","bottom":""}},"Tablet":{"unit":"%","dimension":{"right":"0","left":"0","top":"0"}},"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"animation":{"type":{"Desktop":"fadeInUp"},"duration":"normal"}} -->
<h2 class="wp-block-gutenverse-heading guten-element guten-khF1fp animated guten-element-hide desktop-fadeInUp">Pricing Plans For Every Need</h2>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/text-editor {"elementId":"guten-X6L5Ry","alignment":{"Desktop":"center"},"textColor":{"type":"variable","id":"theme-2"},"typography":{"type":"variable","id":"a0sRlN","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"weight":"400"},"margin":{"Desktop":[],"Tablet":[],"Mobile":[]},"padding":{"Desktop":{"unit":"%","dimension":{"right":"28","left":"28","top":"","bottom":""}},"Tablet":{"unit":"%","dimension":{"right":"15","left":"15"}},"Mobile":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"animation":{"type":{"Desktop":"fadeInUp"},"duration":"normal","delay":"200"}} -->
<div class="guten-element gutenverse-text-editor guten-X6L5Ry animated guten-element-hide desktop-fadeInUp"><div class="text-content-inner"><!-- wp:paragraph -->
<p>Lorem ipsum dolor sit amet consectetur adipiscing elit semper dalar elementum tempus hac tellus libero accumsan dolor sit amet consctur.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:gutenverse/text-editor -->

<!-- wp:gutenverse/section {"layout":"fullwidth","isChild":true,"gap":"no","elementId":"guten-1R37Bj","margin":{"Desktop":{"unit":"px","dimension":{"top":"60"}}},"padding":{"Desktop":[]}} -->
<div class="section-wrapper" data-id="1R37Bj"><section class="wp-block-gutenverse-section guten-element guten-section guten-1R37Bj layout-fullwidth align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":33.3,"Tablet":50,"Mobile":null},"elementId":"guten-daLnJA","background":{"type":"default","color":{"type":"variable","id":"theme-11"},"fixed":{"Desktop":false}},"backgroundOverlay":{"type":"default","image":{"Desktop":{"id":3948,"image":"' . esc_url( SOCIATIC_URI ) . 'assets/img/pricing-bg-orange.webp"},"Tablet":{"id":3948,"image":"' . esc_url( SOCIATIC_URI ) . 'assets/img/pricing-bg-orange.webp"}},"position":{"Desktop":"center center","Tablet":"center center"},"repeat":{"Desktop":"no-repeat","Tablet":"no-repeat"},"size":{"Desktop":"custom","Tablet":"cover"},"width":{"Desktop":{"unit":"%","point":"145"}}},"opacity":"1","border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"20","left":"20"}}},"all":{"type":"none","width":"","color":""}},"margin":{"Desktop":{"unit":"px","dimension":{"right":"20"}},"Tablet":{"unit":"px","dimension":{"left":"","right":"0","bottom":"20"}},"Mobile":{"unit":"px","dimension":{"right":"0","bottom":"10"}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"40","right":"40","bottom":"40","left":"40"}},"Tablet":[],"Mobile":[]},"animation":{"type":{"Desktop":"fadeInUp"},"duration":"normal","delay":"500"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-daLnJA animated guten-element-hide desktop-fadeInUp"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="daLnJA"><div class="guten-column-wrapper"><!-- wp:gutenverse/heading {"elementId":"guten-XbGEVF","type":3,"color":{"type":"variable","id":"theme-1"},"typography":{"type":"variable","id":"LzdbXD","font":{"label":"Muli","value":"Muli","type":"google"},"size":{"Desktop":{"point":"34","unit":"px"},"Mobile":{"point":"28","unit":"px"},"Tablet":{"point":"28","unit":"px"}},"weight":"800","lineHeight":{"Desktop":{"unit":"em","point":"1.2"}}},"border":{"radius":{"Desktop":[]}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"","bottom":""}}},"padding":{"Desktop":[]}} -->
<h3 class="wp-block-gutenverse-heading guten-element guten-XbGEVF">Basic</h3>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/advanced-heading {"elementId":"guten-Iruo9j","titleTag":"h3","text":"$39","focusText":" /month","subText":"Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor","showLine":"none","lineMargin":{"Desktop":[]},"mainColor":{"type":"variable","id":"theme-1"},"mainTypography":{"type":"variable","id":"BBe7T5","font":{"label":"Muli","value":"Muli","type":"google"},"size":{"Desktop":{"point":"50","unit":"px"},"Mobile":{"point":"48","unit":"px"},"Tablet":{"point":"48","unit":"px"}},"weight":"800","lineHeight":{"Desktop":{"unit":"em","point":"1"}}},"mainMargin":{"Desktop":{"unit":"px","dimension":{"bottom":"","top":"","right":"","left":""}},"Tablet":[],"Mobile":[]},"mainPadding":{"Desktop":[],"Tablet":[],"Mobile":[]},"focusColor":{"type":"variable","id":"theme-2"},"focusTypography":{"type":"variable","id":"vRlVnG","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"18","unit":"px"},"Tablet":{"point":"18","unit":"px"},"Mobile":{"point":"16","unit":"px"}},"weight":"400","lineHeight":{"Desktop":{"unit":"em","point":"1.2"}}},"focusMargin":{"Desktop":[],"Tablet":[]},"focusPadding":{"Desktop":[],"Tablet":[]},"subColor":{"type":"variable","id":"theme-2"},"subTypography":{"type":"variable","id":"a0sRlN","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"weight":"400"},"subMargin":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"","bottom":"","left":""}},"Mobile":{"unit":"px","dimension":{"top":""}}},"subPadding":{"Desktop":[],"Mobile":[]},"margin":{"Desktop":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"10","bottom":"10"}}}} -->
<div class="guten-element guten-advanced-heading guten-Iruo9j"><div class="heading-section "><h3 class="heading-title">$39<span class="heading-focus"> /month</span></h3></div><span class="heading-subtitle">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor</span></div>
<!-- /wp:gutenverse/advanced-heading -->

<!-- wp:gutenverse/divider {"elementId":"guten-sJVXFi","width":{"Desktop":"100"},"dividerColor":{"r":238,"g":223,"b":215,"a":0.64},"size":{"Desktop":"1.5"},"gap":{"Desktop":"20"},"border":{"radius":{"Desktop":[]}},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"","top":"","right":"","left":""}}},"padding":{"Desktop":[]}} -->
<div class="wp-block-gutenverse-divider guten-element guten-divider guten-sJVXFi"><div class="guten-divider-wrapper"><div class="guten-divider-default guten-divider-line guten-divider-regular"></div></div></div>
<!-- /wp:gutenverse/divider -->

<!-- wp:gutenverse/icon-list {"elementId":"guten-P1Wspa","spaceBetween":{"Desktop":"10"},"iconColor":{"type":"variable","id":"theme-6"},"textColor":{"type":"variable","id":"theme-2"},"textIndent":{"Desktop":"15"},"textTypography":{"type":"variable","id":"a0sRlN","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"weight":"400"},"margin":{"Desktop":[]},"padding":{"Desktop":[]}} -->
<div class="guten-element guten-icon-list guten-P1Wspa"><!-- wp:gutenverse/icon-list-item {"elementId":"guten-AHIjEA"} -->
<div class="guten-element guten-icon-list-item guten-AHIjEA"><a id="guten-AHIjEA"><i class="fas fa-check"></i><span class="list-text ">3 &nbsp;Social profiles</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-lJikp5"} -->
<div class="guten-element guten-icon-list-item guten-lJikp5"><a id="guten-lJikp5"><i class="fas fa-check"></i><span class="list-text ">12 Team members</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-rJX9wn"} -->
<div class="guten-element guten-icon-list-item guten-rJX9wn"><a id="guten-rJX9wn"><i class="fas fa-check"></i><span class="list-text ">5 Competitors per profile</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-QW3YwA"} -->
<div class="guten-element guten-icon-list-item guten-QW3YwA"><a id="guten-QW3YwA"><i class="fas fa-check"></i><span class="list-text ">Hashtags per profile</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-bJ1gwZ"} -->
<div class="guten-element guten-icon-list-item guten-bJ1gwZ"><a id="guten-bJ1gwZ"><i class="fas fa-check"></i><span class="list-text ">Free Platform Access</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-rOk722"} -->
<div class="guten-element guten-icon-list-item guten-rOk722"><a id="guten-rOk722"><i class="fas fa-check"></i><span class="list-text ">Monthly Target</span></a></div>
<!-- /wp:gutenverse/icon-list-item --></div>
<!-- /wp:gutenverse/icon-list -->

<!-- wp:gutenverse/button {"elementId":"guten-wDHni5","content":"Get Started","url":"#","buttonWidth":{"Desktop":"100"},"paddingButton":{"Desktop":{"unit":"px","dimension":{"top":"18","bottom":"18","right":"36","left":"36"}}},"buttonBackground":{"type":"default","color":{"type":"variable","id":"theme-0"}},"buttonBackgroundHover":{"type":"default","color":{"type":"variable","id":"theme-10"}},"buttonBorder":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"100","right":"100","bottom":"100","left":"100"}}},"all":{"type":"none","width":"1","color":{"r":152,"g":109,"b":248,"a":1}}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"40"}}},"padding":{"Desktop":[]},"color":{"type":"variable","id":"white"},"iconColor":{"type":"variable","id":"white"},"typography":{"type":"variable","id":"pnXC9z","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"},"Tablet":{"point":"16","unit":"px"},"Mobile":{"point":"16","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1"}},"weight":"500"},"positioningType":{"Desktop":"default"}} -->
<div class="guten-element guten-button-wrapper guten-wDHni5"><a class="guten-button guten-button-sm" href="#"><span>Get Started</span></a></div>
<!-- /wp:gutenverse/button --></div></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":33.3,"Tablet":100},"elementId":"guten-FV33M1","order":{"Tablet":3},"background":{"type":"default","color":{"type":"variable","id":"theme-0"}},"backgroundOverlay":{"type":"default","image":{"Desktop":{"id":3949,"image":"' . esc_url( SOCIATIC_URI ) . 'assets/img/pricing-bg-purple.webp"},"Tablet":{"id":3949,"image":"' . esc_url( SOCIATIC_URI ) . 'assets/img/pricing-bg-purple.webp"},"Mobile":{"id":3949,"image":"' . esc_url( SOCIATIC_URI ) . 'assets/img/pricing-bg-purple.webp"}},"position":{"Desktop":"center center","Tablet":"center center"},"repeat":{"Desktop":"no-repeat","Tablet":"no-repeat"},"size":{"Desktop":"custom","Tablet":"cover"},"width":{"Desktop":{"unit":"%","point":"145"}}},"opacity":"0.2","horizontalAlign":{"Desktop":"default","Tablet":"center"},"border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"20","left":"20"}}}},"margin":{"Desktop":{"unit":"px","dimension":{"right":"10","left":"10"}},"Tablet":{"unit":"%","dimension":{"left":"26","right":"26","bottom":""}},"Mobile":{"unit":"px","dimension":{"left":"0","top":"10","bottom":"10","right":"0"}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"40","right":"40","bottom":"50","left":"40"}},"Tablet":[],"Mobile":[]},"animation":{"type":{"Desktop":"fadeInUp"},"duration":"normal","delay":"300"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-FV33M1 animated guten-element-hide desktop-fadeInUp"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="FV33M1"><div class="guten-column-wrapper"><!-- wp:gutenverse/heading {"elementId":"guten-H3K0Vx","type":3,"color":{"type":"variable","id":"white"},"typography":{"type":"variable","id":"LzdbXD","font":{"label":"Muli","value":"Muli","type":"google"},"size":{"Desktop":{"point":"34","unit":"px"},"Mobile":{"point":"28","unit":"px"},"Tablet":{"point":"28","unit":"px"}},"weight":"800","lineHeight":{"Desktop":{"unit":"em","point":"1.2"}}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}}},"padding":{"Desktop":[]}} -->
<h3 class="wp-block-gutenverse-heading guten-element guten-H3K0Vx">Premium</h3>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/advanced-heading {"elementId":"guten-wDUJT3","titleTag":"h3","text":"$49","focusText":" /month","subText":"Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor","showLine":"none","lineMargin":{"Desktop":[]},"mainColor":{"type":"variable","id":"white"},"mainTypography":{"type":"variable","id":"BBe7T5","font":{"label":"Muli","value":"Muli","type":"google"},"size":{"Desktop":{"point":"50","unit":"px"},"Mobile":{"point":"48","unit":"px"},"Tablet":{"point":"48","unit":"px"}},"weight":"800","lineHeight":{"Desktop":{"unit":"em","point":"1"}}},"mainMargin":{"Desktop":{"unit":"px","dimension":{"bottom":"","top":"","right":"","left":""}},"Tablet":[]},"mainPadding":{"Desktop":[],"Tablet":[]},"focusColor":{"type":"variable","id":"white"},"focusTypography":{"type":"variable","id":"vRlVnG","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"18","unit":"px"},"Tablet":{"point":"18","unit":"px"},"Mobile":{"point":"16","unit":"px"}},"weight":"400","lineHeight":{"Desktop":{"unit":"em","point":"1.2"}}},"focusMargin":{"Desktop":[],"Tablet":[]},"focusPadding":{"Desktop":[],"Tablet":[]},"subColor":{"type":"variable","id":"white"},"subTypography":{"type":"variable","id":"a0sRlN","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"weight":"400"},"subMargin":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"","bottom":"","left":""}},"Tablet":[]},"subPadding":{"Desktop":[],"Tablet":[]},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":""}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"10","bottom":"10","right":"","left":""}}}} -->
<div class="guten-element guten-advanced-heading guten-wDUJT3"><div class="heading-section "><h3 class="heading-title">$49<span class="heading-focus"> /month</span></h3></div><span class="heading-subtitle">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor</span></div>
<!-- /wp:gutenverse/advanced-heading -->

<!-- wp:gutenverse/divider {"elementId":"guten-dIqIgW","width":{"Desktop":"100"},"dividerColor":{"r":131,"g":93,"b":207,"a":0.47},"size":{"Desktop":"1.5"},"gap":{"Desktop":"20"},"border":{"radius":{"Desktop":[]}},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"","top":"","right":"","left":""}}},"padding":{"Desktop":[]}} -->
<div class="wp-block-gutenverse-divider guten-element guten-divider guten-dIqIgW"><div class="guten-divider-wrapper"><div class="guten-divider-default guten-divider-line guten-divider-regular"></div></div></div>
<!-- /wp:gutenverse/divider -->

<!-- wp:gutenverse/icon-list {"elementId":"guten-R7FjaF","spaceBetween":{"Desktop":"10"},"iconColor":{"type":"variable","id":"white"},"textColor":{"type":"variable","id":"white"},"textIndent":{"Desktop":"15"},"textTypography":{"type":"variable","id":"a0sRlN","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"weight":"400"}} -->
<div class="guten-element guten-icon-list guten-R7FjaF"><!-- wp:gutenverse/icon-list-item {"elementId":"guten-aADcUX"} -->
<div class="guten-element guten-icon-list-item guten-aADcUX"><a id="guten-aADcUX"><i class="fas fa-check"></i><span class="list-text ">3 &nbsp;Social profiles</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-Au6tbG"} -->
<div class="guten-element guten-icon-list-item guten-Au6tbG"><a id="guten-Au6tbG"><i class="fas fa-check"></i><span class="list-text ">12 Team members</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-4jfGAX"} -->
<div class="guten-element guten-icon-list-item guten-4jfGAX"><a id="guten-4jfGAX"><i class="fas fa-check"></i><span class="list-text ">5 Competitors per profile</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-IiHqMI"} -->
<div class="guten-element guten-icon-list-item guten-IiHqMI"><a id="guten-IiHqMI"><i class="fas fa-check"></i><span class="list-text ">Hashtags per profile</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-Il9XwA"} -->
<div class="guten-element guten-icon-list-item guten-Il9XwA"><a id="guten-Il9XwA"><i class="fas fa-check"></i><span class="list-text ">Free Platform Access</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-q56kyd"} -->
<div class="guten-element guten-icon-list-item guten-q56kyd"><a id="guten-q56kyd"><i class="fas fa-check"></i><span class="list-text ">Monthly Target</span></a></div>
<!-- /wp:gutenverse/icon-list-item --></div>
<!-- /wp:gutenverse/icon-list -->

<!-- wp:gutenverse/button {"elementId":"guten-7bFnnW","content":"Get Started","url":"#","buttonWidth":{"Desktop":"100"},"paddingButton":{"Desktop":{"unit":"px","dimension":{"top":"18","bottom":"18","right":"36","left":"36"}}},"buttonBackground":{"type":"default","color":{"type":"variable","id":"white"}},"buttonBackgroundHover":{"type":"default","color":{"type":"variable","id":"theme-1"}},"buttonBorder":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"100","right":"100","bottom":"100","left":"100"}}},"all":{"type":"none","width":"1","color":{"r":152,"g":109,"b":248,"a":1}}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"40"}}},"padding":{"Desktop":[]},"color":{"type":"variable","id":"theme-0"},"iconColor":{"type":"variable","id":"GfRTUM"},"typography":{"type":"variable","id":"pnXC9z","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"},"Tablet":{"point":"16","unit":"px"},"Mobile":{"point":"16","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1"}},"weight":"500"},"hoverTextColor":{"type":"variable","id":"white"},"positioningType":{"Desktop":"default"}} -->
<div class="guten-element guten-button-wrapper guten-7bFnnW"><a class="guten-button guten-button-sm" href="#"><span>Get Started</span></a></div>
<!-- /wp:gutenverse/button --></div></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":33.3,"Tablet":50,"Mobile":null},"elementId":"guten-266nmF","background":{"type":"default","color":{"type":"variable","id":"theme-11"}},"backgroundOverlay":{"type":"default","image":{"Desktop":{"id":3948,"image":"' . esc_url( SOCIATIC_URI ) . 'assets/img/pricing-bg-orange.webp"},"Tablet":{"id":3948,"image":"' . esc_url( SOCIATIC_URI ) . 'assets/img/pricing-bg-orange.webp"}},"position":{"Desktop":"center center","Tablet":"center center"},"repeat":{"Desktop":"no-repeat","Tablet":"no-repeat"},"size":{"Desktop":"custom","Tablet":"cover"},"width":{"Desktop":{"unit":"%","point":"145"}},"blendMode":{"Desktop":"normal"}},"opacity":"1","border":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"20","right":"20","bottom":"20","left":"20"}}},"all":{"type":"none"}},"margin":{"Desktop":{"unit":"px","dimension":{"left":"20"}},"Tablet":{"unit":"px","dimension":{"left":"","right":"","top":"","bottom":"20"}},"Mobile":{"unit":"px","dimension":{"right":"0","left":"0","top":"10","bottom":"10"}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"40","right":"40","bottom":"50","left":"40"}},"Tablet":[],"Mobile":[]},"animation":{"type":{"Desktop":"fadeInUp"},"duration":"normal","delay":"700"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-266nmF animated guten-element-hide desktop-fadeInUp"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="266nmF"><div class="guten-column-wrapper"><!-- wp:gutenverse/heading {"elementId":"guten-iOU0DK","type":3,"color":{"type":"variable","id":"theme-1"},"typography":{"type":"variable","id":"LzdbXD","font":{"label":"Muli","value":"Muli","type":"google"},"size":{"Desktop":{"point":"34","unit":"px"},"Mobile":{"point":"28","unit":"px"},"Tablet":{"point":"28","unit":"px"}},"weight":"800","lineHeight":{"Desktop":{"unit":"em","point":"1.2"}}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"","right":"","bottom":"","left":""}}},"padding":{"Desktop":[]}} -->
<h3 class="wp-block-gutenverse-heading guten-element guten-iOU0DK">Standard</h3>
<!-- /wp:gutenverse/heading -->

<!-- wp:gutenverse/advanced-heading {"elementId":"guten-BWB8qw","titleTag":"h3","text":"$29","focusText":" /month","subText":"Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor","showLine":"none","lineMargin":{"Desktop":[]},"mainColor":{"type":"variable","id":"theme-1"},"mainTypography":{"type":"variable","id":"BBe7T5","font":{"label":"Muli","value":"Muli","type":"google"},"size":{"Desktop":{"point":"50","unit":"px"},"Mobile":{"point":"48","unit":"px"},"Tablet":{"point":"48","unit":"px"}},"weight":"800","lineHeight":{"Desktop":{"unit":"em","point":"1"}}},"mainMargin":{"Desktop":{"unit":"px","dimension":{"bottom":"","top":"","right":"","left":""}},"Tablet":[]},"mainPadding":{"Desktop":[],"Tablet":[]},"focusColor":{"type":"variable","id":"theme-2"},"focusTypography":{"type":"variable","id":"vRlVnG","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"18","unit":"px"},"Tablet":{"point":"18","unit":"px"},"Mobile":{"point":"16","unit":"px"}},"weight":"400","lineHeight":{"Desktop":{"unit":"em","point":"1.2"}}},"focusMargin":{"Desktop":[],"Tablet":[]},"focusPadding":{"Desktop":[],"Tablet":[]},"subColor":{"type":"variable","id":"theme-2"},"subTypography":{"type":"variable","id":"a0sRlN","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"weight":"400"},"subMargin":{"Desktop":{"unit":"px","dimension":{"top":"20"}}},"subPadding":{"Desktop":[]},"margin":{"Desktop":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"10","bottom":"10"}}}} -->
<div class="guten-element guten-advanced-heading guten-BWB8qw"><div class="heading-section "><h3 class="heading-title">$29<span class="heading-focus"> /month</span></h3></div><span class="heading-subtitle">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor</span></div>
<!-- /wp:gutenverse/advanced-heading -->

<!-- wp:gutenverse/divider {"elementId":"guten-PVNnsM","width":{"Desktop":"100"},"dividerColor":{"r":238,"g":223,"b":215,"a":0.64},"size":{"Desktop":"1.5"},"gap":{"Desktop":"20"},"border":{"radius":{"Desktop":[]}},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"","top":"","right":"","left":""}}},"padding":{"Desktop":[]}} -->
<div class="wp-block-gutenverse-divider guten-element guten-divider guten-PVNnsM"><div class="guten-divider-wrapper"><div class="guten-divider-default guten-divider-line guten-divider-regular"></div></div></div>
<!-- /wp:gutenverse/divider -->

<!-- wp:gutenverse/icon-list {"elementId":"guten-7rW339","spaceBetween":{"Desktop":"10"},"iconColor":{"type":"variable","id":"theme-6"},"textColor":{"type":"variable","id":"theme-2"},"textIndent":{"Desktop":"15"},"textTypography":{"type":"variable","id":"a0sRlN","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"weight":"400"}} -->
<div class="guten-element guten-icon-list guten-7rW339"><!-- wp:gutenverse/icon-list-item {"elementId":"guten-OUdL2E"} -->
<div class="guten-element guten-icon-list-item guten-OUdL2E"><a id="guten-OUdL2E"><i class="fas fa-check"></i><span class="list-text ">3 &nbsp;Social profiles</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-KK9SvJ"} -->
<div class="guten-element guten-icon-list-item guten-KK9SvJ"><a id="guten-KK9SvJ"><i class="fas fa-check"></i><span class="list-text ">12 Team members</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-ZHfVVV"} -->
<div class="guten-element guten-icon-list-item guten-ZHfVVV"><a id="guten-ZHfVVV"><i class="fas fa-check"></i><span class="list-text ">5 Competitors per profile</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-sDZVof"} -->
<div class="guten-element guten-icon-list-item guten-sDZVof"><a id="guten-sDZVof"><i class="fas fa-check"></i><span class="list-text ">Hashtags per profile</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-iObZbZ"} -->
<div class="guten-element guten-icon-list-item guten-iObZbZ"><a id="guten-iObZbZ"><i class="fas fa-check"></i><span class="list-text ">Free Platform Access</span></a></div>
<!-- /wp:gutenverse/icon-list-item -->

<!-- wp:gutenverse/icon-list-item {"elementId":"guten-oNQTbl"} -->
<div class="guten-element guten-icon-list-item guten-oNQTbl"><a id="guten-oNQTbl"><i class="fas fa-check"></i><span class="list-text ">Monthly Target</span></a></div>
<!-- /wp:gutenverse/icon-list-item --></div>
<!-- /wp:gutenverse/icon-list -->

<!-- wp:gutenverse/button {"elementId":"guten-XTQkMV","content":"Get Started","url":"#","buttonWidth":{"Desktop":"100"},"paddingButton":{"Desktop":{"unit":"px","dimension":{"top":"18","bottom":"18","right":"36","left":"36"}},"Tablet":[]},"buttonBackground":{"type":"default","color":{"type":"variable","id":"theme-0"}},"buttonBackgroundHover":{"type":"default","color":{"type":"variable","id":"theme-10"}},"buttonBorder":{"radius":{"Desktop":{"unit":"px","dimension":{"top":"100","right":"100","bottom":"100","left":"100"}}},"all":{"type":"none","width":"1","color":{"r":152,"g":109,"b":248,"a":1}}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"40"}}},"padding":{"Desktop":[]},"color":{"type":"variable","id":"white"},"iconColor":{"r":255,"g":255,"b":255,"a":1},"typography":{"type":"variable","id":"pnXC9z","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"},"Tablet":{"point":"16","unit":"px"},"Mobile":{"point":"16","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1"}},"weight":"500"},"positioningType":{"Desktop":"default"}} -->
<div class="guten-element guten-button-wrapper guten-XTQkMV"><a class="guten-button guten-button-sm" href="#"><span>Get Started</span></a></div>
<!-- /wp:gutenverse/button --></div></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
);
