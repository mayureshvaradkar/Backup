<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Sociatic Core Home Hero', 'sociatic' ),
	'categories' => array( 'sociatic-core' ),
	'content'    => '<!-- wp:group {"layout":{"type":"constrained","contentSize":""}} -->
<div class="wp-block-group"><!-- wp:cover {"url":"' . esc_url( SOCIATIC_URI ) . 'assets/img/bg-hero-core.webp","id":3810,"dimRatio":0,"minHeight":750,"isDark":false} -->
<div class="wp-block-cover is-light" style="min-height:750px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-3810" alt="" src="' . esc_url( SOCIATIC_URI ) . 'assets/img/bg-hero-core.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"margin":{"top":"150px","bottom":"100px"}}},"layout":{"type":"constrained","contentSize":"1190px"}} -->
<div class="wp-block-group" style="margin-top:150px;margin-bottom:100px"><!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"30px","left":"30px"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"top","style":{"spacing":{"padding":{"top":"120px"}}}} -->
<div class="wp-block-column is-vertically-aligned-top" style="padding-top:120px"><!-- wp:group {"style":{"spacing":{"blockGap":"20px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":1,"style":{"typography":{"fontStyle":"normal","fontWeight":"800","lineHeight":"1.1"}},"textColor":"theme-1","className":"sociatic-animate sociatic-move-right sociatic-delay-1","fontSize":"heading-1","fontFamily":"mulish"} -->
<h1 class="wp-block-heading sociatic-animate sociatic-move-right sociatic-delay-1 has-theme-1-color has-text-color has-mulish-font-family has-heading-1-font-size" style="font-style:normal;font-weight:800;line-height:1.1">The Best Solution For Your Social Media Strategies</h1>
<!-- /wp:heading -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"80%","className":"sociatic-animate sociatic-move-right sociatic-delay-3"} -->
<div class="wp-block-column sociatic-animate sociatic-move-right sociatic-delay-3" style="flex-basis:80%"><!-- wp:paragraph {"style":{"typography":{"fontSize":"18px","lineHeight":"1.5","fontStyle":"normal","fontWeight":"400"}},"textColor":"theme-2","fontFamily":"mulish"} -->
<p class="has-theme-2-color has-text-color has-mulish-font-family" style="font-size:18px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"20.33%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:20.33%"></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:group {"style":{"spacing":{"blockGap":"20px"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:buttons {"className":"is-style-custombuttonstyle3 sociatic-animate sociatic-move-right sociatic-delay-5"} -->
<div class="wp-block-buttons is-style-custombuttonstyle3 sociatic-animate sociatic-move-right sociatic-delay-5"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#">Learn More</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:image {"id":6203,"width":55,"height":55,"sizeSlug":"full","linkDestination":"custom","className":"sociatic-animate sociatic-move-right sociatic-delay-7"} -->
<figure class="wp-block-image size-full is-resized sociatic-animate sociatic-move-right sociatic-delay-7"><a href="#"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/play-button.webp" alt="" class="wp-image-6203" style="width:55px;height:55px" width="55" height="55"/></a></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"sizeSlug":"large","linkDestination":"none","className":"sociatic-animate sociatic-move-up sociatic-delay-1"} -->
<figure class="wp-block-image size-large sociatic-animate sociatic-move-up sociatic-delay-1"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/image-core-hero.webp" alt=""/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group -->',
);
