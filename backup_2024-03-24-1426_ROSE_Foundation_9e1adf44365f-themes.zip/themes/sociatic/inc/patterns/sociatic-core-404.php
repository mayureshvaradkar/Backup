<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Sociatic Core 404', 'sociatic' ),
	'categories' => array( 'sociatic-core' ),
	'content'    => '<!-- wp:group {"layout":{"type":"constrained","contentSize":""}} -->
<div class="wp-block-group"><!-- wp:cover {"url":"' . esc_url( SOCIATIC_URI ) . 'assets/img/404-bg-core.webp","id":3794,"dimRatio":0,"minHeight":894,"isDark":false} -->
<div class="wp-block-cover is-light" style="min-height:894px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-3794" alt="" src="' . esc_url( SOCIATIC_URI ) . 'assets/img/404-bg-core.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"margin":{"top":"100px","bottom":"100px"},"padding":{"right":"20px","left":"20px","top":"50px"}}},"layout":{"type":"constrained","contentSize":"1190px"}} -->
<div class="wp-block-group" style="margin-top:100px;margin-bottom:100px;padding-top:50px;padding-right:20px;padding-left:20px"><!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontStyle":"normal","fontWeight":"800","lineHeight":"1.1"}},"textColor":"theme-0","className":"sociatic-animate sociatic-move-up sociatic-delay-1   ","fontSize":"font-not-found","fontFamily":"mulish"} -->
<h1 class="wp-block-heading has-text-align-center sociatic-animate sociatic-move-up sociatic-delay-1 has-theme-0-color has-text-color has-mulish-font-family has-font-not-found-font-size" style="font-style:normal;font-weight:800;line-height:1.1">404</h1>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","style":{"typography":{"lineHeight":"1.1","fontStyle":"normal","fontWeight":"800"},"spacing":{"margin":{"bottom":"20px","top":"20px"}}},"textColor":"theme-1","className":" sociatic-animate sociatic-move-up sociatic-delay-3","fontSize":"heading-2","fontFamily":"mulish"} -->
<h2 class="wp-block-heading has-text-align-center sociatic-animate sociatic-move-up sociatic-delay-3 has-theme-1-color has-text-color has-mulish-font-family has-heading-2-font-size" style="margin-top:20px;margin-bottom:20px;font-style:normal;font-weight:800;line-height:1.1">Page Not Found</h2>
<!-- /wp:heading -->

<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"40px"}}},"layout":{"type":"constrained","contentSize":"400px"}} -->
<div class="wp-block-group" style="margin-bottom:40px"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-text-align-center has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">The page you are looking for might have been removed had its name changed or is temporarily unavailable</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:search {"label":"Search","showLabel":false,"width":50,"widthUnit":"%","buttonText":"Search","align":"center","style":{"border":{"radius":"50px","width":"1px"},"typography":{"fontSize":"14px","fontStyle":"normal","fontWeight":"400","lineHeight":"2"}},"borderColor":"theme-13","backgroundColor":"theme-0","textColor":"white","fontFamily":"mulish"} /--></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group -->',
);
