<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Sociatic Core Icon', 'sociatic' ),
	'categories' => array( 'sociatic-core' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"right":"20px","left":"20px"}}},"layout":{"type":"constrained","contentSize":"1190px"}} -->
<div class="wp-block-group" style="padding-right:20px;padding-left:20px"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"align":"right","id":3813,"width":65,"height":95,"sizeSlug":"full","linkDestination":"custom","className":"scrollable-element sociatic-margin-top-n50"} -->
<figure class="wp-block-image alignright size-full is-resized scrollable-element sociatic-margin-top-n50"><a href="#sociatic-about"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/button-down.webp" alt="" class="wp-image-3813" style="width:65px;height:95px" width="65" height="95"/></a></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->',
);
