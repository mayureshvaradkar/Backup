<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Sociatic Core Footer', 'sociatic' ),
	'categories' => array( 'sociatic-core' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"100px","bottom":"30px","right":"20px","left":"20px"}}},"backgroundColor":"theme-1","layout":{"type":"constrained","contentSize":"1190px"}} -->
<div class="wp-block-group has-theme-1-background-color has-background" style="padding-top:100px;padding-right:20px;padding-bottom:30px;padding-left:20px"><!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"top":"32px","left":"32px"},"margin":{"bottom":"80px"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center" style="margin-bottom:80px"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:site-title {"style":{"typography":{"fontSize":"36px","fontStyle":"normal","fontWeight":"800","lineHeight":"1"},"spacing":{"margin":{"bottom":"20px"}}},"textColor":"white","fontFamily":"mulish"} /-->

<!-- wp:paragraph {"style":{"spacing":{"padding":{"right":"50px","top":"5px"}},"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.7"}},"textColor":"white","fontFamily":"hind-siliguri"} -->
<p class="has-white-color has-text-color has-hind-siliguri-font-family" style="padding-top:5px;padding-right:50px;font-size:16px;font-style:normal;font-weight:400;line-height:1.7">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor.</p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"iconColor":"white","iconColorValue":"#ffffff","iconBackgroundColor":"theme-6","iconBackgroundColorValue":"#fc7629","size":"has-normal-icon-size","style":{"spacing":{"blockGap":{"top":"20px","left":"20px"},"margin":{"top":"40px"}}},"className":"is-style-default"} -->
<ul class="wp-block-social-links has-normal-icon-size has-icon-color has-icon-background-color is-style-default" style="margin-top:40px"><!-- wp:social-link {"url":"#","service":"facebook"} /-->

<!-- wp:social-link {"url":"#","service":"instagram"} /-->

<!-- wp:social-link {"url":"#","service":"twitter"} /-->

<!-- wp:social-link {"url":"#","service":"linkedin"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:group {"style":{"spacing":{"blockGap":"10px","margin":{"bottom":"0px"},"padding":{"top":"0px","bottom":"0px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:0px;padding-top:0px;padding-bottom:0px"><!-- wp:image {"id":3836,"width":15,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/message-icon-list.webp" alt="" class="wp-image-3836" style="width:15px" width="15"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"},"spacing":{"margin":{"top":"15px"}}},"textColor":"white","fontFamily":"hind-siliguri"} -->
<p class="has-white-color has-text-color has-hind-siliguri-font-family" style="margin-top:15px;font-size:16px;font-style:normal;font-weight:400">example@example.com</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"10px","margin":{"bottom":"0px","top":"0px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-top:0px;margin-bottom:0px"><!-- wp:image {"id":3837,"width":15,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/phone-icon-list.webp" alt="" class="wp-image-3837" style="width:15px" width="15"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400"},"spacing":{"margin":{"top":"10px"}}},"textColor":"white","fontFamily":"hind-siliguri"} -->
<p class="has-white-color has-text-color has-hind-siliguri-font-family" style="margin-top:10px;font-size:16px;font-style:normal;font-weight:400">+62 4321-234-11</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"padding":{"top":"70px"}}}} -->
<div class="wp-block-column is-vertically-aligned-center" style="padding-top:70px"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.7"},"spacing":{"margin":{"bottom":"20px"}}},"textColor":"white","fontFamily":"hind-siliguri"} -->
<p class="has-white-color has-text-color has-hind-siliguri-font-family" style="margin-bottom:20px;font-size:16px;font-style:normal;font-weight:400;line-height:1.7">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"is-style-custombuttonstyle4","layout":{"type":"flex","justifyContent":"right"}} -->
<div class="wp-block-buttons is-style-custombuttonstyle4"><!-- wp:button {"width":100,"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"500"}},"fontFamily":"hind-siliguri"} -->
<div class="wp-block-button has-custom-width wp-block-button__width-100 has-custom-font-size has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:500"><a class="wp-block-button__link wp-element-button" href="#">Get Started</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"style":{"typography":{"fontSize":"14px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"},"spacing":{"margin":{"bottom":"20px"}}},"textColor":"white","fontFamily":"hind-siliguri"} -->
<p class="has-white-color has-text-color has-hind-siliguri-font-family" style="margin-bottom:20px;font-size:14px;font-style:normal;font-weight:400;line-height:1">Copyright © 2023. All rights reserved.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"style":{"spacing":{"blockGap":"50px"}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"right"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"style":{"typography":{"fontStyle":"normal","fontWeight":"400","fontSize":"14px","lineHeight":"1"}},"textColor":"white","fontFamily":"hind-siliguri"} -->
<p class="has-white-color has-text-color has-hind-siliguri-font-family" style="font-size:14px;font-style:normal;font-weight:400;line-height:1">Privacy Policy</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"14px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"white","fontFamily":"hind-siliguri"} -->
<p class="has-white-color has-text-color has-hind-siliguri-font-family" style="font-size:14px;font-style:normal;font-weight:400;line-height:1">Terms &amp; Condition</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->',
);
