<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Sociatic Core Testimonial', 'sociatic' ),
	'categories' => array( 'sociatic-core' ),
	'content'    => '<!-- wp:group {"layout":{"type":"constrained","contentSize":""}} -->
<div class="wp-block-group"><!-- wp:cover {"url":"' . esc_url( SOCIATIC_URI ) . 'assets/img/testimonial-bg-core.webp","id":3833,"dimRatio":0,"minHeight":580,"isDark":false} -->
<div class="wp-block-cover is-light" style="min-height:580px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-3833" alt="" src="' . esc_url( SOCIATIC_URI ) . 'assets/img/testimonial-bg-core.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"padding":{"top":"80px","bottom":"80px"}}},"layout":{"type":"constrained","contentSize":"1190px"}} -->
<div class="wp-block-group" style="padding-top:80px;padding-bottom:80px"><!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"60px","left":"60px"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading {"style":{"typography":{"fontStyle":"normal","fontWeight":"800","lineHeight":"1.2"},"spacing":{"margin":{"bottom":"30px"}}},"textColor":"theme-1","className":"sociatic-animate sociatic-move-right sociatic-delay-1","fontSize":"heading-2","fontFamily":"mulish"} -->
<h2 class="wp-block-heading sociatic-animate sociatic-move-right sociatic-delay-1 has-theme-1-color has-text-color has-mulish-font-family has-heading-2-font-size" style="margin-bottom:30px;font-style:normal;font-weight:800;line-height:1.2">Don’t Take Our Word, See What Our Client Say</h2>
<!-- /wp:heading -->

<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"30px"}}},"className":"sociatic-animate sociatic-move-right sociatic-delay-3","layout":{"type":"constrained","contentSize":"530px","justifyContent":"left"}} -->
<div class="wp-block-group sociatic-animate sociatic-move-right sociatic-delay-3" style="margin-bottom:30px"><!-- wp:paragraph {"align":"left","style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"},"spacing":{"margin":{"bottom":"20px"}}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-text-align-left has-theme-2-color has-text-color has-hind-siliguri-font-family" style="margin-bottom:20px;font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Etatleo nam lorem scelerisque mi porttitor gravida quam id ac nunc varius sapien odio nascetur magna ante arcu sed nibh gravida ultrices pharetra fringilla habitant turpis&nbsp;nascetur magna ante arcu sed nibh magna congue.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"className":"sociatic-animate sociatic-move-right sociatic-delay-3"} -->
<div class="wp-block-column sociatic-animate sociatic-move-right sociatic-delay-3"><!-- wp:group {"style":{"spacing":{"blockGap":"5px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"10px"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:heading {"style":{"typography":{"fontSize":"36px","fontStyle":"normal","fontWeight":"800","lineHeight":"1.1"}},"textColor":"theme-1","fontFamily":"mulish"} -->
<h2 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family" style="font-size:36px;font-style:normal;font-weight:800;line-height:1.1">789</h2>
<!-- /wp:heading -->

<!-- wp:heading {"style":{"typography":{"fontSize":"30px","lineHeight":"1.5","fontStyle":"normal","fontWeight":"800"}},"textColor":"theme-6","fontFamily":"mulish"} -->
<h2 class="wp-block-heading has-theme-6-color has-text-color has-mulish-font-family" style="font-size:30px;font-style:normal;font-weight:800;line-height:1.5">%</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"400"}},"textColor":"theme-2","fontFamily":"mulish"} -->
<p class="has-theme-2-color has-text-color has-mulish-font-family" style="font-size:18px;font-style:normal;font-weight:400">Positive Reviews</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"sociatic-animate sociatic-move-right sociatic-delay-5"} -->
<div class="wp-block-column sociatic-animate sociatic-move-right sociatic-delay-5"><!-- wp:group {"style":{"spacing":{"blockGap":"5px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"10px"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:heading {"style":{"typography":{"fontSize":"36px","fontStyle":"normal","fontWeight":"800","lineHeight":"1.1"}},"textColor":"theme-1","fontFamily":"mulish"} -->
<h2 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family" style="font-size:36px;font-style:normal;font-weight:800;line-height:1.1">240</h2>
<!-- /wp:heading -->

<!-- wp:heading {"style":{"typography":{"fontSize":"30px","lineHeight":"1.5","fontStyle":"normal","fontWeight":"800"}},"textColor":"theme-6","fontFamily":"mulish"} -->
<h2 class="wp-block-heading has-theme-6-color has-text-color has-mulish-font-family" style="font-size:30px;font-style:normal;font-weight:800;line-height:1.5">%</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"400"}},"textColor":"theme-2","fontFamily":"mulish"} -->
<p class="has-theme-2-color has-text-color has-mulish-font-family" style="font-size:18px;font-style:normal;font-weight:400">Company growth</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"sociatic-animate sociatic-move-right sociatic-delay-7"} -->
<div class="wp-block-column sociatic-animate sociatic-move-right sociatic-delay-7"><!-- wp:group {"style":{"spacing":{"blockGap":"5px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"10px"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:heading {"style":{"typography":{"fontSize":"36px","fontStyle":"normal","fontWeight":"800","lineHeight":"1.1"}},"textColor":"theme-1","fontFamily":"mulish"} -->
<h2 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family" style="font-size:36px;font-style:normal;font-weight:800;line-height:1.1">485</h2>
<!-- /wp:heading -->

<!-- wp:heading {"style":{"typography":{"fontSize":"30px","lineHeight":"1.5","fontStyle":"normal","fontWeight":"800"}},"textColor":"theme-6","fontFamily":"mulish"} -->
<h2 class="wp-block-heading has-theme-6-color has-text-color has-mulish-font-family" style="font-size:30px;font-style:normal;font-weight:800;line-height:1.5">%</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"400"}},"textColor":"theme-2","fontFamily":"mulish"} -->
<p class="has-theme-2-color has-text-color has-mulish-font-family" style="font-size:18px;font-style:normal;font-weight:400">Active Clients</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"padding":{"top":"30px"}}},"className":"sociatic-animate sociatic-move-left sociatic-delay-1"} -->
<div class="wp-block-column is-vertically-aligned-center sociatic-animate sociatic-move-left sociatic-delay-1" style="padding-top:30px"><!-- wp:group {"layout":{"type":"constrained","contentSize":"","justifyContent":"right"}} -->
<div class="wp-block-group"><!-- wp:columns {"verticalAlignment":"center","style":{"border":{"radius":"20px"},"spacing":{"padding":{"top":"50px","right":"50px","bottom":"50px","left":"50px"}}},"backgroundColor":"white"} -->
<div class="wp-block-columns are-vertically-aligned-center has-white-background-color has-background" style="border-radius:20px;padding-top:50px;padding-right:50px;padding-bottom:50px;padding-left:50px"><!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"blockGap":"20px"}}} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"20px"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":3834,"width":60,"height":60,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/client-image.webp" alt="" class="wp-image-3834" style="width:60px;height:60px" width="60" height="60"/></figure>
<!-- /wp:image -->

<!-- wp:group {"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":5,"style":{"typography":{"lineHeight":"1.1","fontStyle":"normal","fontWeight":"800"},"spacing":{"margin":{"bottom":"5px"}}},"textColor":"theme-1","fontSize":"heading-5","fontFamily":"mulish"} -->
<h5 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family has-heading-5-font-size" style="margin-bottom:5px;font-style:normal;font-weight:800;line-height:1.1">Julie Diaz</h5>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.7"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:15px;font-style:normal;font-weight:400;line-height:1.7">Manager</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:image {"id":3835,"width":64,"height":46,"sizeSlug":"full","linkDestination":"none","className":"hide-in-mobile"} -->
<figure class="wp-block-image size-full is-resized hide-in-mobile"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/quotes.webp" alt="" class="wp-image-3835" style="width:64px;height:46px" width="64" height="46"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"},"spacing":{"margin":{"top":"30px"}}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="margin-top:30px;font-size:15px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea magna aliqua. Ut enim ad commodo consequat.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group -->',
);
