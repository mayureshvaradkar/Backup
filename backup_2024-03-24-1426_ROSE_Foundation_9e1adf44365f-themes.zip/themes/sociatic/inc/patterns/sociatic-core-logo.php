<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Sociatic Core Logo', 'sociatic' ),
	'categories' => array( 'sociatic-core' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"50px","bottom":"50px","right":"20px","left":"20px"}}},"layout":{"type":"constrained","contentSize":"1190px"}} -->
<div class="wp-block-group" style="padding-top:50px;padding-right:20px;padding-bottom:50px;padding-left:20px"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"25%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:25%"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"80%","style":{"spacing":{"padding":{"bottom":"20px"}}}} -->
<div class="wp-block-column" style="padding-bottom:20px;flex-basis:80%"><!-- wp:heading {"level":4,"style":{"typography":{"fontStyle":"normal","fontWeight":"800"}},"textColor":"theme-1","fontSize":"heading-4","fontFamily":"mulish"} -->
<h4 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family has-heading-4-font-size" style="font-style:normal;font-weight:800">Some of brand we work with</h4>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"33.33%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:33.33%"></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"75%","style":{"spacing":{"blockGap":"0px","padding":{"bottom":"20px"}}}} -->
<div class="wp-block-column is-vertically-aligned-center" style="padding-bottom:20px;flex-basis:75%"><!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"60px","left":"60px"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"style":{"spacing":{"blockGap":"20px"}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:image {"id":3814,"width":185,"height":45,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/financio.webp" alt="" class="wp-image-3814" style="width:185px;height:45px" width="185" height="45"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":3815,"width":180,"height":43,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/echelon.webp" alt="" class="wp-image-3815" style="width:180px;height:43px" width="180" height="43"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":3816,"width":182,"height":44,"sizeSlug":"full","linkDestination":"none","className":"hide-in-mobile"} -->
<figure class="wp-block-image size-full is-resized hide-in-mobile"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/nettiz.webp" alt="" class="wp-image-3816" style="width:182px;height:44px" width="182" height="44"/></figure>
<!-- /wp:image -->

<!-- wp:image {"id":3817,"width":179,"height":43,"sizeSlug":"full","linkDestination":"none","className":"hide-in-mobile"} -->
<figure class="wp-block-image size-full is-resized hide-in-mobile"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/zever.webp" alt="" class="wp-image-3817" style="width:179px;height:43px" width="179" height="43"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->',
);
