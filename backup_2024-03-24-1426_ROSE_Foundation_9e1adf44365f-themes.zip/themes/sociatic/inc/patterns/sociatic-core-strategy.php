<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Sociatic Core Strategy', 'sociatic' ),
	'categories' => array( 'sociatic-core' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"120px","bottom":"50px","right":"20px","left":"20px"}}},"layout":{"type":"constrained","contentSize":"1190px"}} -->
<div class="wp-block-group" style="padding-top:120px;padding-right:20px;padding-bottom:50px;padding-left:20px"><!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"40px","left":"40px"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"style":{"typography":{"fontStyle":"normal","fontWeight":"800","lineHeight":"1.1"},"spacing":{"margin":{"bottom":"20px"}}},"textColor":"theme-1","className":"sociatic-animate sociatic-move-right sociatic-delay-1","fontSize":"heading-2","fontFamily":"mulish"} -->
<h2 class="wp-block-heading sociatic-animate sociatic-move-right sociatic-delay-1 has-theme-1-color has-text-color has-mulish-font-family has-heading-2-font-size" style="margin-bottom:20px;font-style:normal;font-weight:800;line-height:1.1">Create A Social Media Strategy That Works</h2>
<!-- /wp:heading -->

<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"40px"}}},"className":"sociatic-animate sociatic-move-right sociatic-delay-3","layout":{"type":"constrained","justifyContent":"left","contentSize":"500px"}} -->
<div class="wp-block-group sociatic-animate sociatic-move-right sociatic-delay-3" style="margin-bottom:40px"><!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"20px"}},"className":"sociatic-animate sociatic-move-right sociatic-delay-3","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group sociatic-animate sociatic-move-right sociatic-delay-3"><!-- wp:image {"id":3828,"width":70,"height":70,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/proffesional-icon.webp" alt="" class="wp-image-3828" style="width:70px;height:70px" width="70" height="70"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":4,"style":{"typography":{"fontStyle":"normal","fontWeight":"800","lineHeight":"1.2"}},"textColor":"theme-1","fontSize":"heading-4","fontFamily":"mulish"} -->
<h4 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family has-heading-4-font-size" style="font-style:normal;font-weight:800;line-height:1.2">Profesional Team</h4>
<!-- /wp:heading -->

<!-- wp:group {"layout":{"type":"constrained","justifyContent":"left","contentSize":"400px"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"20px","margin":{"top":"35px"}}},"className":"sociatic-animate sociatic-move-right sociatic-delay-5","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group sociatic-animate sociatic-move-right sociatic-delay-5" style="margin-top:35px"><!-- wp:image {"id":3829,"width":70,"height":70,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/target-icon.webp" alt="" class="wp-image-3829" style="width:70px;height:70px" width="70" height="70"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":4,"style":{"typography":{"fontStyle":"normal","fontWeight":"800","lineHeight":"1.2"}},"textColor":"theme-1","fontSize":"heading-4","fontFamily":"mulish"} -->
<h4 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family has-heading-4-font-size" style="font-style:normal;font-weight:800;line-height:1.2">Target Oriented</h4>
<!-- /wp:heading -->

<!-- wp:group {"layout":{"type":"constrained","justifyContent":"left","contentSize":"400px"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"20px","margin":{"top":"35px"}}},"className":"sociatic-animate sociatic-move-right sociatic-delay-7","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group sociatic-animate sociatic-move-right sociatic-delay-7" style="margin-top:35px"><!-- wp:image {"id":3830,"width":70,"height":70,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/rocket-icon.webp" alt="" class="wp-image-3830" style="width:70px;height:70px" width="70" height="70"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":4,"style":{"typography":{"fontStyle":"normal","fontWeight":"800","lineHeight":"1.2"}},"textColor":"theme-1","fontSize":"heading-4","fontFamily":"mulish"} -->
<h4 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family has-heading-4-font-size" style="font-style:normal;font-weight:800;line-height:1.2">Succes Guarantee</h4>
<!-- /wp:heading -->

<!-- wp:group {"layout":{"type":"constrained","justifyContent":"left","contentSize":"400px"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","className":"sociatic-animate sociatic-move-up sociatic-delay-1"} -->
<div class="wp-block-column is-vertically-aligned-center sociatic-animate sociatic-move-up sociatic-delay-1"><!-- wp:image {"id":5225,"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/graphic-image-1024x824.webp" alt="" class="wp-image-5225"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->',
);
