<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Sociatic Core Pricing', 'sociatic' ),
	'categories' => array( 'sociatic-core' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"50px","bottom":"120px","right":"20px","left":"20px"}}},"layout":{"type":"constrained","contentSize":"1190px"}} -->
<div class="wp-block-group" style="padding-top:50px;padding-right:20px;padding-bottom:120px;padding-left:20px"><!-- wp:group {"layout":{"type":"constrained","contentSize":"710px"}} -->
<div class="wp-block-group"><!-- wp:heading {"textAlign":"center","style":{"typography":{"fontStyle":"normal","fontWeight":"800","lineHeight":"1.1"},"spacing":{"margin":{"bottom":"20px"}}},"textColor":"theme-1","className":"sociatic-animate sociatic-up-right sociatic-delay-1","fontSize":"heading-2","fontFamily":"mulish"} -->
<h2 class="wp-block-heading has-text-align-center sociatic-animate sociatic-up-right sociatic-delay-1 has-theme-1-color has-text-color has-mulish-font-family has-heading-2-font-size" style="margin-bottom:20px;font-style:normal;font-weight:800;line-height:1.1">Pricing Plans For Every Need</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"sociatic-animate sociatic-move-up sociatic-delay-3","layout":{"type":"constrained","contentSize":"550px"}} -->
<div class="wp-block-group sociatic-animate sociatic-move-up sociatic-delay-3"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-text-align-center has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur adipiscing elit semper dalar elementum tempus hac tellus libero accumsan dolor sit amet consctur.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:columns {"style":{"spacing":{"margin":{"top":"60px"},"blockGap":{"top":"30px","left":"30px"}}}} -->
<div class="wp-block-columns" style="margin-top:60px"><!-- wp:column {"className":" sociatic-animate sociatic-move-up sociatic-delay-5"} -->
<div class="wp-block-column sociatic-animate sociatic-move-up sociatic-delay-5"><!-- wp:group {"style":{"border":{"width":"0px","style":"none","radius":"20px"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="border-style:none;border-width:0px;border-radius:20px"><!-- wp:cover {"url":"' . esc_url( SOCIATIC_URI ) . 'assets/img/pricing-bg-orange-core.webp","id":3831,"dimRatio":0,"isDark":false,"style":{"spacing":{"padding":{"top":"40px","right":"40px","bottom":"40px","left":"40px"}}},"className":"sociatic-radius-25"} -->
<div class="wp-block-cover is-light sociatic-radius-25" style="padding-top:40px;padding-right:40px;padding-bottom:40px;padding-left:40px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-3831" alt="" src="' . esc_url( SOCIATIC_URI ) . 'assets/img/pricing-bg-orange-core.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3,"style":{"typography":{"lineHeight":"1.2","fontStyle":"normal","fontWeight":"800"},"spacing":{"margin":{"bottom":"20px"}}},"textColor":"theme-1","fontSize":"heading-3","fontFamily":"mulish"} -->
<h3 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family has-heading-3-font-size" style="margin-bottom:20px;font-style:normal;font-weight:800;line-height:1.2">Basic</h3>
<!-- /wp:heading -->

<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"20px"},"blockGap":"5px"}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"bottom"}} -->
<div class="wp-block-group" style="margin-bottom:20px"><!-- wp:heading {"style":{"typography":{"fontSize":"50px","fontStyle":"normal","fontWeight":"800","lineHeight":"1.2"}},"textColor":"theme-1","fontFamily":"mulish"} -->
<h2 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family" style="font-size:50px;font-style:normal;font-weight:800;line-height:1.2">$39</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.2"},"spacing":{"margin":{"bottom":"10px"}}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="margin-bottom:10px;font-size:18px;font-style:normal;font-weight:400;line-height:1.2">/mounth</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"border":{"bottom":{"color":"#f1e4dd","width":"1px"}},"spacing":{"padding":{"bottom":"20px"},"margin":{"bottom":"20px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="border-bottom-color:#f1e4dd;border-bottom-width:1px;margin-bottom:20px;padding-bottom:20px"><!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#fc7629","#fc7629"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">3 &nbsp;Social profiles</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#fc7629","#fc7629"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">12 Team members</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#fc7629","#fc7629"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">5 Competitors per profile</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#fc7629","#fc7629"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">Hashtags per profile</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#fc7629","#fc7629"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">Free Platform Access</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#fc7629","#fc7629"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">Monthly Target</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"margin":{"top":"40px"}}},"layout":{"type":"constrained","contentSize":"1190px"}} -->
<div class="wp-block-group" style="margin-top:40px"><!-- wp:buttons {"className":"is-style-custombuttonstyle4","layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons is-style-custombuttonstyle4"><!-- wp:button {"textAlign":"center","width":100} -->
<div class="wp-block-button has-custom-width wp-block-button__width-100"><a class="wp-block-button__link has-text-align-center wp-element-button" href="#">Get Started</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"sociatic-animate sociatic-move-up sociatic-delay-3"} -->
<div class="wp-block-column sociatic-animate sociatic-move-up sociatic-delay-3"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:cover {"url":"' . esc_url( SOCIATIC_URI ) . 'assets/img/pricing-purple-bg.webp","id":3832,"dimRatio":0,"isDark":false,"style":{"spacing":{"padding":{"top":"40px","right":"40px","bottom":"40px","left":"40px"}}},"className":"sociatic-radius-25"} -->
<div class="wp-block-cover is-light sociatic-radius-25" style="padding-top:40px;padding-right:40px;padding-bottom:40px;padding-left:40px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-3832" alt="" src="' . esc_url( SOCIATIC_URI ) . 'assets/img/pricing-purple-bg.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3,"style":{"typography":{"lineHeight":"1.2","fontStyle":"normal","fontWeight":"800"},"spacing":{"margin":{"bottom":"20px"}}},"textColor":"white","fontSize":"heading-3","fontFamily":"mulish"} -->
<h3 class="wp-block-heading has-white-color has-text-color has-mulish-font-family has-heading-3-font-size" style="margin-bottom:20px;font-style:normal;font-weight:800;line-height:1.2">Premium</h3>
<!-- /wp:heading -->

<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"20px"},"blockGap":"5px"}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"bottom"}} -->
<div class="wp-block-group" style="margin-bottom:20px"><!-- wp:heading {"style":{"typography":{"fontSize":"50px","fontStyle":"normal","fontWeight":"800","lineHeight":"1.2"}},"textColor":"white","fontFamily":"mulish"} -->
<h2 class="wp-block-heading has-white-color has-text-color has-mulish-font-family" style="font-size:50px;font-style:normal;font-weight:800;line-height:1.2">$49</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.2"},"spacing":{"margin":{"bottom":"10px"}}},"textColor":"white","fontFamily":"hind-siliguri"} -->
<p class="has-white-color has-text-color has-hind-siliguri-font-family" style="margin-bottom:10px;font-size:18px;font-style:normal;font-weight:400;line-height:1.2">/mounth</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"border":{"bottom":{"color":"var:preset|color|theme-15","width":"1px"}},"spacing":{"padding":{"bottom":"20px"},"margin":{"bottom":"20px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="border-bottom-color:var(--wp--preset--color--theme-15);border-bottom-width:1px;margin-bottom:20px;padding-bottom:20px"><!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"white","fontFamily":"hind-siliguri"} -->
<p class="has-white-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["rgb(253, 253, 253)","rgb(254, 253, 253)"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"white","fontFamily":"hind-siliguri"} -->
<p class="has-white-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">3 &nbsp;Social profiles</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#ffffff","#ffffff"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"white","fontFamily":"hind-siliguri"} -->
<p class="has-white-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">12 Team members</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#ffffff","#ffffff"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"white","fontFamily":"hind-siliguri"} -->
<p class="has-white-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">5 Competitors per profile</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#ffffff","#ffffff"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"white","fontFamily":"hind-siliguri"} -->
<p class="has-white-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">Hashtags per profile</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#ffffff","#ffffff"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"white","fontFamily":"hind-siliguri"} -->
<p class="has-white-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">Free Platform Access</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#ffffff","#ffffff"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"white","fontFamily":"hind-siliguri"} -->
<p class="has-white-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">Monthly Target</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"margin":{"top":"40px"}}},"layout":{"type":"constrained","contentSize":"1190px"}} -->
<div class="wp-block-group" style="margin-top:40px"><!-- wp:buttons {"className":"is-style-custombuttonstyle5","layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons is-style-custombuttonstyle5"><!-- wp:button {"textAlign":"center","width":100} -->
<div class="wp-block-button has-custom-width wp-block-button__width-100"><a class="wp-block-button__link has-text-align-center wp-element-button" href="#">Get Started</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"sociatic-animate sociatic-move-up sociatic-delay-7"} -->
<div class="wp-block-column sociatic-animate sociatic-move-up sociatic-delay-7"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:cover {"url":"' . esc_url( SOCIATIC_URI ) . 'assets/img/pricing-bg-orange-core.webp","id":3831,"dimRatio":0,"isDark":false,"style":{"spacing":{"padding":{"top":"40px","right":"40px","bottom":"40px","left":"40px"}}},"className":"sociatic-radius-25"} -->
<div class="wp-block-cover is-light sociatic-radius-25" style="padding-top:40px;padding-right:40px;padding-bottom:40px;padding-left:40px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-3831" alt="" src="' . esc_url( SOCIATIC_URI ) . 'assets/img/pricing-bg-orange-core.webp" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"type":"flex","orientation":"vertical","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:heading {"level":3,"style":{"typography":{"lineHeight":"1.2","fontStyle":"normal","fontWeight":"800"},"spacing":{"margin":{"bottom":"20px"}}},"textColor":"theme-1","fontSize":"heading-3","fontFamily":"mulish"} -->
<h3 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family has-heading-3-font-size" style="margin-bottom:20px;font-style:normal;font-weight:800;line-height:1.2">Standard</h3>
<!-- /wp:heading -->

<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"20px"},"blockGap":"5px"}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"bottom"}} -->
<div class="wp-block-group" style="margin-bottom:20px"><!-- wp:heading {"style":{"typography":{"fontSize":"50px","fontStyle":"normal","fontWeight":"800","lineHeight":"1.2"}},"textColor":"theme-1","fontFamily":"mulish"} -->
<h2 class="wp-block-heading has-theme-1-color has-text-color has-mulish-font-family" style="font-size:50px;font-style:normal;font-weight:800;line-height:1.2">$29</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.2"},"spacing":{"margin":{"bottom":"10px"}}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="margin-bottom:10px;font-size:18px;font-style:normal;font-weight:400;line-height:1.2">/mounth</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"border":{"bottom":{"color":"#f1e4dd","width":"1px"}},"spacing":{"padding":{"bottom":"20px"},"margin":{"bottom":"20px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="border-bottom-color:#f1e4dd;border-bottom-width:1px;margin-bottom:20px;padding-bottom:20px"><!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1.5"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1.5">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#fc7629","#fc7629"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">3 &nbsp;Social profiles</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#fc7629","#fc7629"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">12 Team members</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#fc7629","#fc7629"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">5 Competitors per profile</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#fc7629","#fc7629"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">Hashtags per profile</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#fc7629","#fc7629"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">Free Platform Access</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"blockGap":"5px","margin":{"bottom":"10px"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-bottom:10px"><!-- wp:image {"id":3848,"width":26,"height":26,"sizeSlug":"full","linkDestination":"none","style":{"color":{"duotone":["#fc7629","#fc7629"]}}} -->
<figure class="wp-block-image size-full is-resized"><img src="' . esc_url( SOCIATIC_URI ) . 'assets/img/check.webp" alt="" class="wp-image-3848" style="width:26px;height:26px" width="26" height="26"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"400","lineHeight":"1"}},"textColor":"theme-2","fontFamily":"hind-siliguri"} -->
<p class="has-theme-2-color has-text-color has-hind-siliguri-font-family" style="font-size:16px;font-style:normal;font-weight:400;line-height:1">Monthly Target</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"margin":{"top":"40px"}}},"layout":{"type":"constrained","contentSize":"1190px"}} -->
<div class="wp-block-group" style="margin-top:40px"><!-- wp:buttons {"className":"is-style-custombuttonstyle4","layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons is-style-custombuttonstyle4"><!-- wp:button {"textAlign":"center","width":100} -->
<div class="wp-block-button has-custom-width wp-block-button__width-100"><a class="wp-block-button__link has-text-align-center wp-element-button" href="#">Get Started</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->',
);
