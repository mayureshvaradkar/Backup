<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Sociatic Gutenverse Single Hero', 'sociatic' ),
	'categories' => array( 'sociatic-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1190"},"gap":"no","elementId":"guten-6gzmBc","background":{"type":"default","color":{"r":255,"g":246,"b":239,"a":1}},"backgroundOverlay":{"type":"default","image":{"Desktop":{"id":3895,"image":"' . esc_url( SOCIATIC_URI ) . 'assets/img/hero-page-bg.webp"},"Tablet":{"id":3944,"image":"' . esc_url( SOCIATIC_URI ) . 'assets/img/bg-hero.webp"},"Mobile":{"id":3944,"image":"' . esc_url( SOCIATIC_URI ) . 'assets/img/bg-hero.webp"}},"position":{"Desktop":"center center","Mobile":"custom","Tablet":"custom"},"repeat":{"Desktop":"no-repeat"},"size":{"Desktop":"default"},"xposition":{"Mobile":{"unit":"%","point":""},"Tablet":{"unit":"%","point":""}},"yposition":{"Mobile":{"unit":"%","point":"42"},"Tablet":{"unit":"%","point":"60"}}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"-100"}},"Tablet":[],"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"220","bottom":"120"}},"Tablet":{"unit":"px","dimension":{"right":"20","left":"20","top":"160","bottom":"100"}},"Mobile":{"unit":"px","dimension":{"right":"20","left":"20","top":"150","bottom":"50"}}}} -->
<div class="section-wrapper" data-id="6gzmBc"><section class="wp-block-gutenverse-section guten-element guten-section guten-6gzmBc layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100,"Tablet":null},"elementId":"guten-KyPELM","border":{"radius":{"Desktop":[]}},"margin":{"Desktop":[]},"padding":{"Desktop":[]}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-KyPELM"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="KyPELM"><div class="guten-column-wrapper"><!-- wp:gutenverse/section {"width":{"Desktop":"1190"},"isChild":true,"gap":"no","elementId":"guten-FjnLeS"} -->
<div class="section-wrapper" data-id="FjnLeS"><section class="wp-block-gutenverse-section guten-element guten-section guten-FjnLeS layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":80,"Tablet":100},"elementId":"guten-YPBrSm","verticalAlign":{"Desktop":"center"},"horizontalAlign":{"Desktop":"default","Tablet":"center"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-YPBrSm"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="YPBrSm"><div class="guten-column-wrapper"><!-- wp:gutenverse/post-title {"elementId":"guten-FWe8oW","alignment":{"Tablet":"center"},"typography":{"type":"variable","id":"1Isv3n","font":{"label":"Muli","value":"Muli","type":"google"},"size":{"Desktop":{"point":"56","unit":"px"},"Mobile":{"point":"36","unit":"px"},"Tablet":{"point":"44","unit":"px"}},"lineHeight":{"Desktop":{"unit":"em","point":"1.1"}},"weight":"800"},"color":{"type":"variable","id":"theme-1"},"colorHover":{"type":"variable","id":"theme-0"},"margin":{"Desktop":{"unit":"px","dimension":{"bottom":"40"}},"Tablet":[]},"padding":{"Desktop":[],"Tablet":[]}} -->
<div class="guten-element guten-post-title guten-FWe8oW"></div>
<!-- /wp:gutenverse/post-title -->

<!-- wp:gutenverse/icon {"elementId":"guten-sVMoOj","icon":"fas fa-user","iconColorOne":{"r":0,"g":0,"b":0,"a":0},"iconSize":{"Desktop":{"point":"18","unit":"px"}},"iconPadding":{"Desktop":"0"},"iconColorTwo":{"type":"variable","id":"theme-6"},"iconShape":"custom","background":{"type":"default","color":{"r":0,"g":0,"b":0,"a":0}},"margin":{"Desktop":{"unit":"px","dimension":{"right":"10"}}},"padding":{"Desktop":[]},"positioningType":{"Desktop":"inline"}} -->
<div class="wp-block-gutenverse-icon guten-element guten-sVMoOj guten-icon"><span class="guten-icon-wrapper custom stacked"><i class="fas fa-user"></i></span></div>
<!-- /wp:gutenverse/icon -->

<!-- wp:gutenverse/post-author {"elementId":"guten-Ot4b1e","typography":{"type":"variable","id":"a0sRlN","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"weight":"400"},"color":{"type":"variable","id":"theme-2"},"colorHover":{"type":"variable","id":"theme-2"},"authorBorder":{"radius":{"Desktop":[]}},"border":{"radius":{"Desktop":[]}},"positioningType":{"Desktop":"inline"}} -->
<div class="guten-element guten-post-author guten-Ot4b1e"></div>
<!-- /wp:gutenverse/post-author -->

<!-- wp:gutenverse/icon {"elementId":"guten-lt0IDn","icon":"fas fa-clock","iconColorOne":{"r":0,"g":0,"b":0,"a":0},"iconSize":{"Desktop":{"point":"18","unit":"px"}},"iconPadding":{"Desktop":"0"},"iconColorTwo":{"type":"variable","id":"theme-6"},"iconShape":"custom","background":{"type":"default","color":{"r":0,"g":0,"b":0,"a":0}},"margin":{"Desktop":{"unit":"px","dimension":{"right":"10","left":"50"}}},"padding":{"Desktop":[]},"positioningType":{"Desktop":"inline"}} -->
<div class="wp-block-gutenverse-icon guten-element guten-lt0IDn guten-icon"><span class="guten-icon-wrapper custom stacked"><i class="fas fa-clock"></i></span></div>
<!-- /wp:gutenverse/icon -->

<!-- wp:gutenverse/post-date {"elementId":"guten-XphJLi","typography":{"type":"variable","id":"a0sRlN","font":{"label":"Hind Siliguri","value":"Hind Siliguri","type":"google"},"size":{"Desktop":{"point":"16","unit":"px"}},"weight":"400"},"color":{"type":"variable","id":"theme-2"},"colorHover":{"type":"variable","id":"theme-2"},"border":{"radius":{"Desktop":[]}},"positioningType":{"Desktop":"inline"}} -->
<div class="guten-element guten-post-date guten-XphJLi"></div>
<!-- /wp:gutenverse/post-date --></div></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":20,"Tablet":40,"Mobile":null},"elementId":"guten-SHYC7e","verticalAlign":{"Desktop":"center","Tablet":"center"},"margin":{"Mobile":[]},"padding":{"Mobile":{"unit":"px","dimension":{"top":"20"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-SHYC7e"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="SHYC7e"><div class="guten-column-wrapper"></div></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
);
