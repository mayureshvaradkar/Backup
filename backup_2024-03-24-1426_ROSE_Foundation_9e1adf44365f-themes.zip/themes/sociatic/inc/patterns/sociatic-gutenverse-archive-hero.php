<?php
/**
 * Pattern content.
 */
return array(
	'title'      => __( 'Sociatic Gutenverse Archive Hero', 'sociatic' ),
	'categories' => array( 'sociatic-gutenverse' ),
	'content'    => '<!-- wp:gutenverse/section {"width":{"Desktop":"1190"},"gap":"no","elementId":"guten-6gzmBc","background":{"type":"default","color":{"r":255,"g":246,"b":239,"a":1}},"backgroundOverlay":{"type":"default","image":{"Desktop":{"id":3895,"image":"' . esc_url( SOCIATIC_URI ) . 'assets/img/hero-page-bg.webp"},"Mobile":{"id":3944,"image":"' . esc_url( SOCIATIC_URI ) . 'assets/img/bg-hero.webp"},"Tablet":{"id":3944,"image":"' . esc_url( SOCIATIC_URI ) . 'assets/img/bg-hero.webp"}},"position":{"Desktop":"center center","Tablet":"custom","Mobile":"custom"},"repeat":{"Desktop":"no-repeat"},"size":{"Desktop":"default"},"xposition":{"Tablet":{"unit":"%","point":""},"Mobile":{"unit":"%","point":""}},"yposition":{"Tablet":{"unit":"%","point":"60"},"Mobile":{"unit":"%","point":"58"}}},"margin":{"Desktop":{"unit":"px","dimension":{"top":"-100"}},"Tablet":[],"Mobile":[]},"padding":{"Desktop":{"unit":"px","dimension":{"top":"200","bottom":"150"}},"Tablet":{"unit":"px","dimension":{"right":"15","left":"15","top":"160"}},"Mobile":{"unit":"px","dimension":{"right":"10","left":"10","top":"140","bottom":"80"}}},"zIndex":{"Desktop":"0"}} -->
<div class="section-wrapper" data-id="6gzmBc"><section class="wp-block-gutenverse-section guten-element guten-section guten-6gzmBc layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":100},"elementId":"guten-KyPELM","border":{"radius":{"Desktop":[]}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-KyPELM"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="KyPELM"><div class="guten-column-wrapper"><!-- wp:gutenverse/section {"width":{"Desktop":"1190"},"isChild":true,"gap":"no","elementId":"guten-FjnLeS"} -->
<div class="section-wrapper" data-id="FjnLeS"><section class="wp-block-gutenverse-section guten-element guten-section guten-FjnLeS layout-boxed align-stretch"><div class="guten-background-overlay"></div><div class="guten-shape-divider guten-shape-divider-top"></div><div class="guten-shape-divider guten-shape-divider-bottom"></div><div class="guten-container guten-column-gap-no"><!-- wp:gutenverse/column {"width":{"Desktop":80,"Tablet":80},"elementId":"guten-YPBrSm","margin":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"padding":{"Desktop":{"unit":"px","dimension":{"top":"0","right":"0","bottom":"0","left":"0"}}},"animation":{"type":{"Desktop":"fadeInUp"},"duration":"normal"}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-YPBrSm animated guten-element-hide desktop-fadeInUp"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="YPBrSm"><div class="guten-column-wrapper"><!-- wp:query-title {"type":"archive","showPrefix":false,"style":{"typography":{"fontStyle":"normal","fontWeight":"800"},"spacing":{"padding":{"top":"0px","right":"0px","bottom":"0px","left":"0px"},"margin":{"top":"0px","right":"0px","bottom":"0px","left":"0px"}}},"textColor":"theme-1","className":"heading-1-page","fontFamily":"mulish"} /--></div></div></div>
<!-- /wp:gutenverse/column -->

<!-- wp:gutenverse/column {"width":{"Desktop":20,"Tablet":20,"Mobile":null},"elementId":"guten-SHYC7e","verticalAlign":{"Desktop":"center","Tablet":"center"},"margin":{"Mobile":[]},"padding":{"Mobile":{"unit":"px","dimension":{"top":"20"}}}} -->
<div class="wp-block-gutenverse-column guten-element guten-column guten-SHYC7e"><div class="guten-background-overlay"></div><div class="sticky-wrapper" data-id="SHYC7e"><div class="guten-column-wrapper"></div></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section --></div></div></div>
<!-- /wp:gutenverse/column --></div></section></div>
<!-- /wp:gutenverse/section -->',
);
