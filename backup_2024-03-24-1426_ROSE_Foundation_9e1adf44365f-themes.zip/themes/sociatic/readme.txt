=== Sociatic ===
Contributors: Jegstudio
Requires at least: 6.3
Tested up to: 6.3
Requires PHP: 7.3
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Sociatic is a WordPress theme that looks great on any device and works with the Gutenverse plugin. It's customizable, making it perfect for Social Media Agency and Social media Marketing. You can use the included core and Gutenverse versions to make it easy to create the website you want. We want to make sure you have the best experience using WordPress to edit your site.

== Copyright ==

Sociatic, 2023 Jegstudio
Sociatic is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.


Self designed images,
* Logo 1 : sociatic/assets/img/Logo-black.webp
* Logo 2 : sociatic/assets/img/Logo-white.webp
* Logo 3 : sociatic/assets/img/kness.webp
* Logo 4 : sociatic/assets/img/xtreme.webp
* Logo 5 : sociatic/assets/img/kavlaw.webp
* Logo 6 : sociatic/assets/img/hypebiz.webp
* Logo 7 : sociatic/assets/img/kavana.webp
* Logo 8 : sociatic/assets/img/zever.webp
* Logo 9 : sociatic/assets/img/nettiz.webp
* Logo 10 : sociatic/assets/img/echelon.webp
* Logo 11 : sociatic/assets/img/financio.webp
* Line : sociatic/assets/img/line.webp
* Background Graphic : sociatic/assets/img/windows.webp
* Graphic 1 : sociatic/assets/img/insight.webp
* Graphic 2 : sociatic/assets/img/Analityc.webp
* Graphic 3 : sociatic/assets/img/growth.webp
* Background Home : sociatic/assets/img/bg-hero.webp
* Background Hero : sociatic/assets/img/hero-page-bg.webp
* Background Service : sociatic/assets/img/bg-service.webp
* Background Testimonial : sociatic/assets/img/testimonial-bg.webp
* Background Pop Up : sociatic/assets/img/popup-bg.webp
* Background 404 : sociatic/assets/img/404-bg.webp
* Background Team : sociatic/assets/img/team-about.webp
* Background Pricing 1 : sociatic/assets/img/pricing-bg-orange.webp
* Background Pricing 2 : sociatic/assets/img/pricing-bg-purple.webp
* Background Home core : sociatic/assets/img/bg-hero-core.webp
* Background Hero core : sociatic/assets/img/hero-page-bg-core.webp
* Background Service core : sociatic/assets/img/bg-service-core.webp
* Background Testimonial core : sociatic/assets/img/testimonial-bg-core.webp
* Background Pop Up core : sociatic/assets/img/popup-core-bg.webp
* Background 404 core : sociatic/assets/img/404-bg-core.webp
* Background Pricing 1 core : sociatic/assets/img/pricing-bg-orange-core.webp
* Background Pricing 2 core : sociatic/assets/img/ricing-purple-bg.webp
* Graphic Core 1 : sociatic/assets/img/image-core-hero.webp
* Graphic Core 2 : sociatic/assets/img/Image-core-about.webp
* Graphic Core 3 : sociatic/assets/img/graphic-image.webp
* Play core : sociatic/assets/img/play-button.webp
* Down Icon Core : sociatic/assets/img/button-down.webp
* likes : sociatic/assets/img/likes.webp
* engagement : sociatic/assets/img/engagement.webp
* satisfied client : sociatic/assets/img/satisfied-client.webp
* user reserch : sociatic/assets/img/user-reserch.webp
Declaring these self designed images under GPL license version 2.0 =
License URL: http://www.gnu.org/licenses/gpl-2.0.html

Icon for theme screenshot,
License: (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)
License URL: https://fontawesome.com/license/free

Icons and Icon Images for block pattern,
License: (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)
License URL: https://fontawesome.com/license/free

Edited Image StockSnap_ZRNIM4IB6S.jpg, Original image by Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-woman-ZRNIM4IB6S

Edited Image StockSnap_6NYVPE6NEB.jpg, Original image by Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-man-6NYVPE6NEB 

Edited Image team-3.jpg, Original image by Kristin Hardwick
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/woman-business-X0XJR9QNN8

Edited Image team-2.jpg, Original image by Matt Moloney
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/confident-business-TMACJ6VLZH 

Edited Image team-1.jpg, Original image by Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-man-IVZBYWKEFM

Edited Image client-image.jpg, Original image by Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-woman-S81ZPXJZUU 

Edited Image ceo.jpg, Original image by Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-man-IVZBYWKEFM

Image for theme screenshot and block pattern
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/license
Source: https://pxhere.com/id/photo/730863

Image for theme screenshot and block pattern
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/license
Source: https://pxhere.com/id/photo/723648

Image for theme screenshot and block pattern
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/license
Source: https://pxhere.com/id/photo/1202722

Image for theme screenshot and block pattern, Credit Rawpixel
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/license
Source: https://pxhere.com/id/photo/1449821

Image for theme screenshot and block pattern, Credit WDnet Studio
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/ipad-tablet-A8XB50N7G1

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-men-Q3N39D0OEJ

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/video-meeting-ZDSQP4E3UL

Image for theme screenshot and block pattern, Credit Matt Moloney
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/laptop-work-FP2WQB568R

Image for theme screenshot and block pattern, Credit LinkedIn Sales Navigator
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/man-reading-Q8ZB5OUXFY

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-woman-FPQIEQBMPA 

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-man-IVZBYWKEFM

Image for theme screenshot and block pattern, Credit Direct Media
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://stocksnap.io/license
Source: https://stocksnap.io/photo/business-woman-S81ZPXJZUU

Google Font Files licenses:

Hind Siliguri
License: Open Font License
License File: sociatic/assets/fonts/hind-siliguri/license.txt

Mulish
License: Open Font License
License File: sociatic/assets/fonts/mulish/license.txt

== Changelog ==

= 1.0.4 - 2024-03-21 =
* Update notice design

= 1.0.3 - 2023-09-05 =
* Fix missing global background color
* Fix email placeholder

= 1.0.2 - 2023-09-04 =
* Add google font details in readme.txt
* Rename google font license from OFL.txt to license.txt

= 1.0.1 - 2023-08-30 =
* Add license file for google font bundled in the theme
* Change email address data to placeholder email

= 1.0.0 - 2023-08-24 =
* Initial release