Compile:
divi-scripts build